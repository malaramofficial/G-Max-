package verify

import com.example.meshchat.core.*
import java.util.PriorityQueue
import java.util.Random
import kotlin.system.exitProcess

var passed = 0
var failed = 0
fun check(cond: Boolean, msg: String) {
    if (cond) { passed++; println("  PASS  $msg") } else { failed++; println("  FAIL  $msg") }
}

// ---------------- simulated radio network (no BLE needed) ----------------

class Timer(val at: Long, val seq: Long, val task: () -> Unit)

class SimNet {
    val nodes = LinkedHashMap<String, SimNode>()
    val adj = HashMap<String, MutableSet<String>>()
    val queue = ArrayDeque<Triple<String, String, ByteArray>>() // to, from, frame
    val wireLog = mutableListOf<Triple<String, String, ByteArray>>() // from, to, frame
    var now = 0L
    private var seq = 0L
    private val timers = PriorityQueue<Timer>(compareBy<Timer>({ it.at }, { it.seq }))

    fun scheduler() = object : Scheduler {
        override fun postDelayed(delayMs: Long, task: () -> Unit) { timers.add(Timer(now + delayMs, seq++, task)) }
    }

    fun link(a: String, b: String) {
        adj.getOrPut(a) { mutableSetOf() }.add(b)
        adj.getOrPut(b) { mutableSetOf() }.add(a)
        nodes[a]!!.router.onPeerConnected(b)
        nodes[b]!!.router.onPeerConnected(a)
    }

    fun run() {
        var guard = 0
        while (guard++ < 200_000) {
            val m = queue.removeFirstOrNull()
            if (m != null) { nodes[m.first]!!.router.onFrame(m.second, m.third); continue }
            val t = timers.poll() ?: return
            now = maxOf(now, t.at); t.task()
        }
        error("simulation did not settle")
    }
}

class SimNode(val name: String, val net: SimNet, val p: Curve25519Provider, private val config: MeshConfig, private val seed: Long) : ContactDirectory, MeshEvents {
    val identity = Identity.generate(p, name)
    val accepted = mutableListOf<Contact>()
    val received = mutableListOf<String>()               // decoded TEXT messages
    val inbound = mutableListOf<Pair<Int, ByteArray>>()  // every non-ack message: (type, payload)
    val deliveredIds = mutableListOf<String>()
    val store: PacketStore = InMemoryPacketStore()       // survives "app restarts"
    val contact get() = Contact(identity.edPublic, identity.xPublic, name)
    lateinit var router: MeshRouter

    init {
        net.nodes[name] = this
        restart()
    }

    /** Simulates the app being killed and started again: new router, same identity and same stored packets. */
    fun restart() {
        router = MeshRouter(
            me = identity, codec = SealedPacketCodec(p), contacts = this,
            transport = object : MeshTransport {
                override fun peers(): Collection<String> = net.adj[name] ?: emptySet()
                override fun send(peerId: String, frame: ByteArray) {
                    net.queue.add(Triple(peerId, name, frame)); net.wireLog.add(Triple(name, peerId, frame))
                }
            },
            scheduler = net.scheduler(), events = this, nowMs = { net.now }, rng = Random(seed), config = config, store = store,
        )
    }

    override fun findAccepted(edPublic: ByteArray) = accepted.firstOrNull { it.edPublic.contentEquals(edPublic) }
    override fun onInbound(from: Contact, type: Int, msgId: ByteArray, timestampMs: Long, payload: ByteArray) {
        inbound.add(type to payload)
        if (type == Wire.TYPE_TEXT) TextPayload.decode(payload)?.let { received.add(it.text) }
    }
    override fun onDelivered(to: Contact, msgId: ByteArray) { deliveredIds.add(msgId.toHex()) }
}

fun befriend(a: SimNode, b: SimNode) { a.accepted.add(b.contact); b.accepted.add(a.contact) }

fun main() {
    val p = JdkCurve25519Provider()
    val codec = SealedPacketCodec(p)

    println("== 1. Identity & contact card ==")
    val id = Identity.generate(p, "माला")
    check(Regex("[A-Z2-7]{5}-[A-Z2-7]{5}").matches(id.userId), "user id format ${id.userId}")
    val card = id.card(p)
    check(card.verify(p), "card signature verifies")
    val viaLink = ContactCard.fromLink(card.toLink())
    check(viaLink != null && viaLink.verify(p) && viaLink.userId == id.userId && viaLink.name == "माला", "QR link round-trip (Hindi name)")
    val bad = card.encode().also { it[40] = (it[40].toInt() xor 1).toByte() }
    check(ContactCard.decode(bad)?.verify(p) != true, "edited card is rejected")
    check(ContactCard.fromLink("meshchat://add/@@@") == null, "garbage link rejected")
    val restored = Identity.fromBytes(id.toBytes())
    check(restored != null && restored.userId == id.userId && restored.name == id.name, "identity save/restore")
    check(Identity.generate(p, "x").userId != id.userId, "two identities get different ids")

    println("== 2. Sealed packet ==")
    val alice = Identity.generate(p, "alice"); val bob = Identity.generate(p, "bob"); val eve = Identity.generate(p, "eve")
    val mid = ByteArray(16) { it.toByte() }
    val pkt = codec.seal(alice, bob.xPublic, Wire.TYPE_TEXT, mid, 1234L, "namaste".toByteArray())
    check(pkt.size == Wire.PACKET_SIZE, "packet is ${pkt.size} bytes")
    val opened = codec.open(bob, pkt)
    check(opened != null && String(opened.payload) == "namaste" && opened.senderEdPublic.contentEquals(alice.edPublic), "recipient decrypts + sees authenticated sender")
    check(codec.open(eve, pkt) == null, "a relay/eavesdropper cannot open it")
    check(codec.open(alice, pkt) == null, "even the sender's own key cannot reopen it")
    check(codec.seal(alice, bob.xPublic, Wire.TYPE_TEXT, mid, 1L, ByteArray(0)).size ==
        codec.seal(alice, bob.xPublic, Wire.TYPE_ACK, mid, 1L, ByteArray(Wire.MAX_PAYLOAD)).size, "empty ack and max text are the same size on the wire")
    var tamperOk = true
    for (pos in listOf(0, 31, 32, 43, 44, 500, pkt.size - 1)) {
        val t = pkt.copyOf(); t[pos] = (t[pos].toInt() xor 0x40).toByte()
        if (codec.open(bob, t) != null) tamperOk = false
    }
    check(tamperOk, "any flipped byte makes the packet invalid")
    check(codec.open(bob, pkt.copyOf(pkt.size - 1)) == null, "truncated packet rejected")
    // signature binds the recipient: re-wrapping alice's inner message for someone else must fail
    check(runCatching { codec.seal(alice, bob.xPublic, 1, mid, 1, ByteArray(Wire.MAX_PAYLOAD + 1)) }.isFailure, "oversize payload refused")

    println("== 3. Fragmenter ==")
    val frame = ByteArray(1086).also { Random(7).nextBytes(it) }
    val chunks = Fragmenter.split(frame, 100, 0xBEEF)
    val ra = Reassembler({ 0L })
    var out: ByteArray? = null
    for (c in chunks.shuffled(Random(3))) out = ra.accept("peer", c) ?: out
    check(chunks.size == 11 && out != null && out.contentEquals(frame), "11 shuffled fragments reassemble")
    var clk = 0L
    val rb = Reassembler({ clk })
    chunks.dropLast(1).forEach { rb.accept("peer", it) }
    clk = 11_000
    check(rb.accept("peer", chunks.last()) == null, "missing fragment + timeout -> nothing delivered")

    println("== 4. Mesh: A-B-C-D-E line, message A -> D ==")
    val net = SimNet(); val cfg = MeshConfig()
    val a = SimNode("A", net, p, cfg, 1); val b = SimNode("B", net, p, cfg, 2); val c = SimNode("C", net, p, cfg, 3)
    val d = SimNode("D", net, p, cfg, 4); val e = SimNode("E", net, p, cfg, 5)
    befriend(a, d); befriend(b, c) // B and C know each other but not A/D
    for ((x, y) in listOf("A" to "B", "B" to "C", "C" to "D", "D" to "E")) net.link(x, y)
    net.run()
    val msg = "नमस्ते D! खाना खाया? 🙏"
    val msgId = a.router.sendText(d.contact, msg)
    net.run()
    check(d.received == listOf(msg), "D received the message exactly once, intact (Hindi + emoji)")
    check(a.deliveredIds == listOf(msgId.toHex()), "A got a delivery receipt (ack came back through the mesh)")
    check(b.received.isEmpty() && c.received.isEmpty() && e.received.isEmpty(), "relays B, C, E raised NO message event / notification")
    check(b.deliveredIds.isEmpty() && c.deliveredIds.isEmpty() && e.deliveredIds.isEmpty(), "relays saw no receipts either")
    val packetFrames = net.wireLog.filter { it.third[0].toInt() == MeshRouter.F_PACKET }.map { it.third }
    check(packetFrames.isNotEmpty() && packetFrames.all { it.size == 2 + Wire.PACKET_SIZE }, "all ${packetFrames.size} packet frames on the air are identical in size")
    val onAir = packetFrames.map { it.copyOfRange(2, it.size) }.distinctBy { it.toHex() }
    check(onAir.all { codec.open(b.identity, it) == null && codec.open(c.identity, it) == null && codec.open(e.identity, it) == null }, "no relay can decrypt any packet that crossed it")
    check(onAir.count { codec.open(d.identity, it) != null } == 1 && onAir.count { codec.open(a.identity, it) != null } == 1, "exactly one packet is for D and one (the ack) for A")
    val dForwarded = net.wireLog.any { it.first == "D" && it.second == "E" && it.third[0].toInt() == MeshRouter.F_PACKET && codec.open(d.identity, it.third.copyOfRange(2, it.third.size)) != null }
    check(dForwarded, "recipient D forwarded its own packet on to E (neighbours cannot tell who it was for)")

    println("== 5. Unknown sender / replay / duplicate msgId ==")
    val f = SimNode("F", net, p, cfg, 6)
    f.accepted.add(d.contact) // F knows D, but D never accepted F
    net.link("F", "E")
    net.run()
    f.router.sendText(d.contact, "spam from stranger")
    net.run()
    check(d.received.size == 1, "message from a non-accepted sender is silently dropped")
    val replayFrame = packetFrames.first()
    d.router.onFrame("C", replayFrame); net.run()
    check(d.received.size == 1, "replayed frame ignored")
    val dup = codec.seal(a.identity, d.identity.xPublic, Wire.TYPE_TEXT, msgId, 99L, "again".toByteArray())
    d.router.onFrame("C", byteArrayOf(MeshRouter.F_PACKET.toByte(), 5) + dup); net.run()
    check(d.received.size == 1, "same message id inside a fresh packet is not delivered twice")
    d.router.onFrame("C", ByteArray(5)); d.router.onFrame("C", byteArrayOf(9, 9, 9)); d.router.onFrame("C", ByteArray(0))
    check(true, "garbage frames do not crash the router")

    println("== 6. Hop limit (TTL=3) ==")
    val net2 = SimNet(); val cfg2 = MeshConfig(initialTtlMin = 3, initialTtlMax = 3)
    val n = (0..4).map { SimNode("n$it", net2, p, cfg2, 10L + it) }
    befriend(n[0], n[3]); befriend(n[0], n[4])
    for (i in 0..3) net2.link("n$i", "n${i + 1}")
    net2.run()
    n[0].router.sendText(n[3].contact, "3 hops"); n[0].router.sendText(n[4].contact, "4 hops")
    net2.run()
    check(n[3].received == listOf("3 hops"), "3 hops away: delivered")
    check(n[4].received.isEmpty(), "4 hops away: not delivered (hop limit works)")

    println("== 7. Store-and-forward (sender alone, meets people later) ==")
    val net3 = SimNet(); val cfg3 = MeshConfig()
    val s = SimNode("S", net3, p, cfg3, 21); val m = SimNode("M", net3, p, cfg3, 22); val r = SimNode("R", net3, p, cfg3, 23)
    befriend(s, r)
    s.router.sendText(r.contact, "sent while nobody around"); net3.run()
    check(s.router.storedCount() == 1 && r.received.isEmpty(), "message waits in S's store, nobody to hear it")
    net3.link("S", "M"); net3.run()
    check(m.router.storedCount() == 1 && m.received.isEmpty(), "S meets M: M carries it blindly, cannot read it")
    net3.now += 3_600_000 // an hour later
    net3.link("M", "R"); net3.run()
    check(r.received == listOf("sent while nobody around"), "M later meets R: delivered")
    check(s.router.storedCount() >= 1, "S keeps it for now")
    net3.now += 25L * 3_600_000
    s.router.purgeExpired(); m.router.purgeExpired()
    check(s.router.storedCount() == 0 && m.router.storedCount() == 0, "stored packets expire after 24h")

    println("== 8. Payload formats ==")
    val someId = ByteArray(16) { (it * 3).toByte() }
    val tp = TextPayload.decode(TextPayload("जवाब", someId).encode())
    check(tp != null && tp.text == "जवाब" && tp.replyTo!!.contentEquals(someId), "text + reply-to round-trip")
    check(TextPayload.decode(TextPayload("plain").encode())!!.replyTo == null, "text without reply")
    val members = listOf(a, b, c).map { it.contact }
    val gi = GroupInfoPayload.decode(GroupInfoPayload(someId, "परिवार", members).encode())
    check(gi != null && gi.name == "परिवार" && gi.members.size == 3 && gi.members[1].edPublic.contentEquals(b.identity.edPublic), "group info round-trip")
    check(GroupInfoPayload.decode(ByteArray(10)) == null, "garbage group info rejected")
    val ep = Endpoint(byteArrayOf(192.toByte(), 168.toByte(), 1, 20), 5050, "DIRECT-mc-ab12", "pass1234")
    val fo = FileOfferPayload.decode(FileOfferPayload(someId, ByteArray(32) { 1 }, 123456789012L, ByteArray(32) { 2 }, "फोटो.jpg", "image/jpeg", ep).encode())
    check(fo != null && fo.size == 123456789012L && fo.name == "फोटो.jpg" && fo.endpoint.lanHost() == "192.168.1.20" && fo.endpoint.ssid == "DIRECT-mc-ab12", "file offer round-trip")
    check(fo!!.encode().size <= Wire.MAX_PAYLOAD, "file offer (${fo.encode().size} bytes) fits in one packet")
    val ci = CallInvitePayload.decode(CallInvitePayload(someId, ByteArray(32) { 9 }, Endpoint(null, 6000, "DIRECT-mc-zz", "pw")).encode())
    check(ci != null && ci.endpoint.lanIp == null && ci.endpoint.port == 6000, "call invite round-trip (Wi-Fi Direct only)")
    check(ReadPayload.decode(ReadPayload(listOf(someId, someId)).encode())!!.ids.size == 2, "read receipt list round-trip")
    check(CallEndPayload.decode(CallEndPayload(someId, CallEndPayload.BUSY).encode())!!.reason == CallEndPayload.BUSY, "call end round-trip")

    println("== 9. Group chat over the mesh (A,B,C,D members; E is a non-member relay) ==")
    val net4 = SimNet(); val cfg4 = MeshConfig()
    val ga = SimNode("A", net4, p, cfg4, 31); val gb = SimNode("B", net4, p, cfg4, 32); val gc = SimNode("C", net4, p, cfg4, 33)
    val gd = SimNode("D", net4, p, cfg4, 34); val ge = SimNode("E", net4, p, cfg4, 35)
    val gAll = listOf(ga, gb, gc, gd)
    for (x in gAll) for (y in gAll) if (x !== y) x.accepted.add(y.contact)
    for ((x, y) in listOf("A" to "B", "B" to "C", "C" to "D", "D" to "E", "E" to "A")) net4.link(x, y)
    net4.run()
    val group = Group(Groups.newId(), "Barmer Friends", gAll.map { it.contact })
    Groups.sendInfo(ga.router, ga.identity, group); net4.run()
    check(listOf(gb, gc, gd).all { n -> n.inbound.any { it.first == Wire.TYPE_GROUP_INFO && GroupInfoPayload.decode(it.second)?.members?.size == 4 } }, "B, C, D all learned the group + its 4 members")
    val gMsgId = Groups.sendText(gb.router, gb.identity, group, "सब लोग आ रहे हो?"); net4.run()
    check(listOf(ga, gc, gd).all { n -> n.inbound.any { it.first == Wire.TYPE_GROUP_TEXT && GroupTextPayload.decode(it.second)?.text?.text == "सब लोग आ रहे हो?" } }, "group text from B reached A, C and D")
    check(gb.deliveredIds.count { it == gMsgId.toHex() } == 3, "B got a delivery receipt from each of the 3 other members")
    check(ge.inbound.isEmpty(), "non-member E (relaying for everyone) received nothing")

    println("== 10. Carried packets survive an app restart ==")
    val net5 = SimNet(); val cfg5 = MeshConfig()
    val s2 = SimNode("S", net5, p, cfg5, 41); val m2 = SimNode("M", net5, p, cfg5, 42); val r2 = SimNode("R", net5, p, cfg5, 43)
    befriend(s2, r2)
    s2.router.sendText(r2.contact, "survives restart"); net5.run()
    check(s2.store.count() == 1, "packet is in S's store")
    s2.restart() // the app was killed; only the store remains
    check(s2.router.storedCount() == 1, "after restart S still carries it")
    net5.link("S", "M"); net5.run(); net5.link("M", "R"); net5.run()
    check(r2.received == listOf("survives restart"), "delivered via M after the restart")

    println("== 11. Backup / restore ==")
    val me = Identity.generate(p, "माला")
    val backup = Backup.export(BackupContent(me, listOf(a.contact, b.contact)), "सही पासफ़्रेज़", iterations = 2000)
    val back = Backup.import(backup, "सही पासफ़्रेज़")
    check(back != null && back.identity.userId == me.userId && back.contacts.size == 2 && back.contacts[1].name == "B", "restore with the right passphrase gives the same ID + contacts")
    val restoredCodecOk = back != null && codec.open(back.identity, codec.seal(alice, back.identity.xPublic, 1, mid, 5L, "x".toByteArray())) != null
    check(restoredCodecOk, "restored keys really decrypt messages sent to the old identity")
    check(Backup.import(backup, "गलत") == null, "wrong passphrase is rejected")
    check(Backup.import(backup.copyOf().also { it[60] = (it[60].toInt() xor 1).toByte() }, "सही पासफ़्रेज़") == null, "damaged backup is rejected")

    println("== 12. File transfer over a (loopback) direct link ==")
    val dir = java.nio.file.Files.createTempDirectory("mcfile").toFile()
    val src = java.io.File(dir, "src.bin").also { it.writeBytes(ByteArray(100_000 + 123).also { b2 -> Random(5).nextBytes(b2) }) }
    val fileId = FileCrypto.newId(); val fileKey = FileCrypto.newKey()
    val server = FileServer(); server.register(fileId, fileKey, src)
    val port = server.start()
    val offer = FileOfferPayload(fileId, fileKey, src.length(), FileCrypto.sha256(src), "src.bin", "application/octet-stream", Endpoint(byteArrayOf(127, 0, 0, 1), port))
    val dst = java.io.File(dir, "dst.bin")
    var lastProgress = 0L
    check(FileClient.fetch("127.0.0.1", port, offer, dst, onProgress = { lastProgress = it }) && dst.readBytes().contentEquals(src.readBytes()) && lastProgress == src.length(), "100 KB file arrives byte-identical (encrypted on the wire)")
    check(!FileClient.fetch("127.0.0.1", port, FileOfferPayload(FileCrypto.newId(), fileKey, 1, ByteArray(32), "x", "x", offer.endpoint), java.io.File(dir, "nope")), "unknown file id is refused")
    check(!FileClient.fetch("127.0.0.1", port, FileOfferPayload(fileId, FileCrypto.newKey(), src.length(), offer.sha256, "x", "x", offer.endpoint), java.io.File(dir, "badkey")), "wrong key fails (nothing readable)")
    check(!FileClient.fetch("127.0.0.1", port, FileOfferPayload(fileId, fileKey, src.length(), ByteArray(32), "x", "x", offer.endpoint), java.io.File(dir, "badhash")) && !java.io.File(dir, "badhash").exists(), "wrong hash is refused and no file is left behind")
    server.stop()
    check(!FileClient.fetch("127.0.0.1", port, offer, java.io.File(dir, "late"), connectTimeoutMs = 500), "server stopped: fetch fails cleanly")
    dir.deleteRecursively()

    println("== 13. Call audio encryption + UDP pipe ==")
    val callKey = ByteArray(32).also { Random(9).nextBytes(it) }
    val cc = CallCrypto(callKey, true); val ce = CallCrypto(callKey, false)
    val frame1 = cc.seal(ByteArray(640) { it.toByte() })
    check(ce.open(frame1)?.contentEquals(ByteArray(640) { it.toByte() }) == true, "callee decrypts caller audio")
    check(ce.open(frame1) == null, "replayed audio packet dropped")
    check(cc.open(frame1) == null, "caller cannot 'open' its own direction (separate nonces)")
    check(ce.open(frame1.copyOf().also { it[20] = (it[20].toInt() xor 1).toByte() }) == null, "tampered audio packet dropped")
    check(CallCrypto(ByteArray(32), false).open(cc.seal(ByteArray(10))) == null, "wrong call key cannot decrypt")
    val callerCh = UdpCallChannel(CallCrypto(callKey, true))                                           // does not know the callee yet
    val calleeCh = UdpCallChannel(CallCrypto(callKey, false), remote = java.net.InetSocketAddress("127.0.0.1", callerCh.port))
    calleeCh.send(ByteArray(0))                                                                          // "hello"
    val hello = callerCh.receive(2000)
    check(hello != null && hello.isEmpty() && callerCh.remote != null, "caller learns the callee's address from an authenticated hello")
    val voice = ByteArray(640) { (it * 7).toByte() }
    callerCh.send(voice)
    check(calleeCh.receive(2000)?.contentEquals(voice) == true, "voice frame flows caller -> callee")
    calleeCh.send(voice.reversedArray())
    check(callerCh.receive(2000)?.contentEquals(voice.reversedArray()) == true, "and callee -> caller")
    val rogue = UdpCallChannel(CallCrypto(ByteArray(32), false), remote = java.net.InetSocketAddress("127.0.0.1", callerCh.port))
    rogue.send(ByteArray(0))
    check(callerCh.receive(500) == null && callerCh.remote!!.port == calleeCh.port, "a stranger's packet is ignored and cannot hijack the call")
    callerCh.close(); calleeCh.close(); rogue.close()

    println()
    println("RESULT: $passed passed, $failed failed")
    exitProcess(if (failed == 0) 0 else 1)
}
