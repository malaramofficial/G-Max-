package com.example.meshchat.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** Chat ids: a 1-to-1 chat uses the contact's userId; a group chat uses "g:" + groupId hex. */
const val GROUP_PREFIX = "g:"

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val userId: String,
    val name: String,
    val edPublic: ByteArray,
    val xPublic: ByteArray,
    val accepted: Boolean = true,
    val blocked: Boolean = false,
    val muted: Boolean = false,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    /** Added automatically because they are in a group with you; hidden from the chat list until a 1-to-1 message exists. */
    val viaGroup: Boolean = false,
)

@Entity(tableName = "chat_groups")
data class GroupEntity(
    @PrimaryKey val groupId: String,      // hex
    val name: String,
    val info: ByteArray,                  // encoded GroupInfoPayload (name + all members)
    val muted: Boolean = false,
    val pinned: Boolean = false,
    val archived: Boolean = false,
)

object Kind { const val TEXT = 0; const val FILE = 1; const val SYSTEM = 2 }
object FileState { const val NONE = 0; const val OFFERED = 1; const val DOWNLOADING = 2; const val DONE = 3; const val FAILED = 4 }

@Entity(
    tableName = "messages",
    indices = [Index(value = ["msgId"], unique = true), Index("chatId")],
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val msgId: String,
    val chatId: String,
    val senderId: String = "",            // userId of the sender ("" = me)
    val senderName: String = "",
    val outgoing: Boolean,
    val kind: Int = Kind.TEXT,
    val text: String = "",
    val replyTo: String? = null,          // msgId hex of the quoted message
    val timestamp: Long,
    val delivered: Boolean = false,       // ✓✓ grey
    val seen: Boolean = false,            // ✓✓ blue
    val unread: Boolean = false,
    val starred: Boolean = false,
    val deleted: Boolean = false,
    val fileName: String? = null,
    val fileMime: String? = null,
    val fileSize: Long = 0,
    val filePath: String? = null,
    val fileState: Int = FileState.NONE,
    val offer: ByteArray? = null,         // encoded FileOfferPayload (incoming files)
)

@Entity(tableName = "statuses")
data class StatusEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val authorId: String,                 // "" = me
    val authorName: String,
    val text: String,
    val timestamp: Long,
)

@Entity(tableName = "packets")
data class PacketEntity(
    @PrimaryKey val idHex: String,
    val id: ByteArray,
    val bytes: ByteArray,
    val fwdTtl: Int,
    val storedAt: Long,
)

data class LastMsg(
    val chatId: String,
    val lastText: String,
    val lastTime: Long,
    val deleted: Boolean,
    val kind: Int,
    val fileName: String?,
    val unread: Int,
)

@Dao
interface ChatDao {
    // ---- contacts & groups ----
    @Query("SELECT * FROM contacts ORDER BY name")
    fun contacts(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE userId = :id")
    suspend fun contact(id: String): ContactEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertContact(c: ContactEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertContactIfAbsent(c: ContactEntity): Long

    @Query("SELECT * FROM chat_groups")
    fun groups(): Flow<List<GroupEntity>>

    @Query("SELECT * FROM chat_groups WHERE groupId = :id")
    suspend fun group(id: String): GroupEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGroup(g: GroupEntity)

    // ---- messages ----
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY timestamp, id")
    fun messages(chatId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE msgId = :msgId")
    suspend fun messageByMsgId(msgId: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun messageById(id: Long): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(m: MessageEntity): Long

    @Update
    suspend fun updateMessage(m: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: Long)

    @Query("UPDATE messages SET delivered = 1 WHERE msgId = :msgId AND outgoing = 1")
    suspend fun markDelivered(msgId: String)

    @Query("UPDATE messages SET seen = 1, delivered = 1 WHERE chatId = :chatId AND outgoing = 1 AND msgId IN (:msgIds)")
    suspend fun markSeen(chatId: String, msgIds: List<String>)

    @Query("SELECT msgId FROM messages WHERE chatId = :chatId AND outgoing = 0 AND unread = 1")
    suspend fun unreadIncomingIds(chatId: String): List<String>

    @Query("UPDATE messages SET unread = 0 WHERE chatId = :chatId AND unread = 1")
    suspend fun markRead(chatId: String)

    @Query("SELECT * FROM messages WHERE starred = 1 AND deleted = 0 ORDER BY timestamp DESC")
    fun starred(): Flow<List<MessageEntity>>

    @Query(
        """SELECT m.chatId AS chatId, m.text AS lastText, m.timestamp AS lastTime, m.deleted AS deleted,
           m.kind AS kind, m.fileName AS fileName,
           (SELECT COUNT(*) FROM messages u WHERE u.chatId = m.chatId AND u.unread = 1) AS unread
           FROM messages m
           WHERE m.id = (SELECT id FROM messages WHERE chatId = m.chatId ORDER BY timestamp DESC, id DESC LIMIT 1)"""
    )
    fun lastMessages(): Flow<List<LastMsg>>

    // ---- status ----
    @Insert
    suspend fun insertStatus(s: StatusEntity)

    @Query("SELECT * FROM statuses WHERE timestamp > :since ORDER BY timestamp DESC")
    fun statuses(since: Long): Flow<List<StatusEntity>>

    @Query("DELETE FROM statuses WHERE timestamp <= :before")
    suspend fun deleteStatusesBefore(before: Long)
}

/** Blocking on purpose: only used from the router's own background thread. */
@Dao
interface PacketDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun put(p: PacketEntity)

    @Query("SELECT * FROM packets WHERE idHex = :id")
    fun get(id: String): PacketEntity?

    @Query("SELECT * FROM packets ORDER BY storedAt DESC LIMIT :n")
    fun newest(n: Int): List<PacketEntity>

    @Query("SELECT COUNT(*) FROM packets")
    fun count(): Int

    @Query("DELETE FROM packets WHERE storedAt < :cutoff")
    fun purgeOlderThan(cutoff: Long)

    @Query("DELETE FROM packets WHERE idHex NOT IN (SELECT idHex FROM packets ORDER BY storedAt DESC LIMIT :max)")
    fun trimTo(max: Int)
}

@Database(
    entities = [ContactEntity::class, GroupEntity::class, MessageEntity::class, StatusEntity::class, PacketEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ChatDao
    abstract fun packetDao(): PacketDao
}
