package com.example.meshchat.core

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Per-packet AES-GCM for call audio. Packet = seq(8) | AES-GCM(pcm) | tag(16). The nonce is
 * direction byte (1 = caller, 2 = callee) + 3 zero bytes + seq, so the two directions never reuse a nonce.
 * A 64-packet sliding window drops replays and duplicates.
 */
class CallCrypto(private val key: ByteArray, private val isCaller: Boolean) {
    private var sendSeq = 0L
    private var highest = -1L
    private var window = 0L

    private fun cipher(mode: Int, dir: Int, seq: Long): Cipher {
        val nonce = ByteBuffer.allocate(12).put(dir.toByte()).put(ByteArray(3)).putLong(seq).array()
        return Cipher.getInstance("AES/GCM/NoPadding").also {
            it.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        }
    }

    @Synchronized
    fun seal(pcm: ByteArray): ByteArray {
        val seq = sendSeq++
        val ct = cipher(Cipher.ENCRYPT_MODE, if (isCaller) 1 else 2, seq).doFinal(pcm)
        return ByteBuffer.allocate(8 + ct.size).putLong(seq).put(ct).array()
    }

    /** Returns the audio, or null if forged, corrupted or a replay. An empty array is a valid keep-alive/hello. */
    @Synchronized
    fun open(packet: ByteArray): ByteArray? {
        if (packet.size < 8 + 16) return null
        val seq = ByteBuffer.wrap(packet).long
        if (seq < 0) return null
        val pt = try {
            cipher(Cipher.DECRYPT_MODE, if (isCaller) 2 else 1, seq).doFinal(packet, 8, packet.size - 8)
        } catch (e: GeneralSecurityException) { return null }
        return if (accept(seq)) pt else null
    }

    private fun accept(seq: Long): Boolean {
        if (seq > highest) {
            val shift = seq - highest
            window = if (shift >= 64) 1L else (window shl shift.toInt()) or 1L
            highest = seq
            return true
        }
        val off = highest - seq
        if (off >= 64) return false
        val bit = 1L shl off.toInt()
        if (window and bit != 0L) return false
        window = window or bit
        return true
    }
}

/**
 * Encrypted UDP audio pipe. The side that does not know the other's address (the caller / Wi-Fi Direct group owner)
 * leaves [remote] null and learns it from the first packet that authenticates.
 */
class UdpCallChannel(private val crypto: CallCrypto, localPort: Int = 0, remote: InetSocketAddress? = null) {
    private val socket = DatagramSocket(localPort)
    @Volatile var remote: InetSocketAddress? = remote
    val port: Int get() = socket.localPort

    fun send(pcm: ByteArray) {
        val r = remote ?: return
        val p = crypto.seal(pcm)
        socket.send(DatagramPacket(p, p.size, r))
    }

    /** Blocks up to [timeoutMs]. Null on timeout or an invalid packet; empty array for a hello/keep-alive. */
    fun receive(timeoutMs: Int): ByteArray? {
        val buf = ByteArray(2048)
        val dp = DatagramPacket(buf, buf.size)
        socket.soTimeout = timeoutMs
        try { socket.receive(dp) } catch (e: SocketTimeoutException) { return null }
        val pcm = crypto.open(dp.data.copyOf(dp.length)) ?: return null
        val from = InetSocketAddress(dp.address, dp.port)
        if (remote != from) remote = from
        return pcm
    }

    fun close() = socket.close()
}
