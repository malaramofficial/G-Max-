package com.example.meshchat.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.meshchat.Graph
import com.example.meshchat.call.VoiceRecorder
import com.example.meshchat.core.ContactCard
import com.example.meshchat.core.GroupInfoPayload
import com.example.meshchat.data.FileState
import com.example.meshchat.data.GROUP_PREFIX
import com.example.meshchat.data.Kind
import com.example.meshchat.data.LastMsg
import com.example.meshchat.data.MessageEntity
import kotlinx.coroutines.launch
import java.io.File

class Nav(
    val open: (String) -> Unit,
    val myCard: () -> Unit,
    val newGroup: () -> Unit,
    val status: () -> Unit,
    val starred: () -> Unit,
    val settings: () -> Unit,
)

data class ChatItem(
    val chatId: String, val title: String, val preview: String, val time: Long?, val unread: Int,
    val pinned: Boolean, val muted: Boolean, val archived: Boolean, val isGroup: Boolean,
)

private fun previewOf(l: LastMsg?): String = when {
    l == null -> "Say hello"
    l.deleted -> "🚫 Message deleted"
    l.kind == Kind.FILE -> "📎 ${l.fileName ?: "File"}"
    else -> l.lastText
}

// ======================================================================== chat list

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatListScreen(g: Graph, nav: Nav) {
    val contacts by remember { g.dao.contacts() }.collectAsState(initial = emptyList())
    val groups by remember { g.dao.groups() }.collectAsState(initial = emptyList())
    val last by remember { g.dao.lastMessages() }.collectAsState(initial = emptyList())
    val nearby by g.nearby.collectAsState()
    var showArchived by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var rowMenu by remember { mutableStateOf<ChatItem?>(null) }

    val lastBy = remember(last) { last.associateBy { it.chatId } }
    val all = remember(contacts, groups, lastBy) {
        val c = contacts.filter { !it.blocked && (!it.viaGroup || lastBy.containsKey(it.userId)) }.map {
            val l = lastBy[it.userId]
            ChatItem(it.userId, it.name, previewOf(l), l?.lastTime, l?.unread ?: 0, it.pinned, it.muted, it.archived, false)
        }
        val gr = groups.map {
            val id = GROUP_PREFIX + it.groupId
            val l = lastBy[id]
            ChatItem(id, it.name, previewOf(l), l?.lastTime, l?.unread ?: 0, it.pinned, it.muted, it.archived, true)
        }
        (c + gr).sortedWith(compareByDescending<ChatItem> { it.pinned }.thenByDescending { it.time ?: 0L })
    }
    val visible = all.filter { it.archived == showArchived }

    Scaffold(
        topBar = {
            BrandTopBar(
                title = {
                    Column {
                        Text(if (showArchived) "Archived" else "MeshChat")
                        Text(if (nearby == 0) "no one nearby" else "$nearby nearby", style = MaterialTheme.typography.bodySmall)
                    }
                },
                onBack = if (showArchived) ({ showArchived = false }) else null,
                actions = {
                    Box {
                        TextButton(onClick = { menuOpen = true }) { Text("⋮", color = Color.White) }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("New group") }, onClick = { menuOpen = false; nav.newGroup() })
                            DropdownMenuItem(text = { Text("Status") }, onClick = { menuOpen = false; nav.status() })
                            DropdownMenuItem(text = { Text("Starred messages") }, onClick = { menuOpen = false; nav.starred() })
                            DropdownMenuItem(text = { Text("Archived (${all.count { it.archived }})") }, onClick = { menuOpen = false; showArchived = true })
                            DropdownMenuItem(text = { Text("My ID / add friend") }, onClick = { menuOpen = false; nav.myCard() })
                            DropdownMenuItem(text = { Text("Settings") }, onClick = { menuOpen = false; nav.settings() })
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = nav.myCard, containerColor = Brand.primary, contentColor = Color.White) { Text("＋") }
        },
    ) { pad ->
        if (visible.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (showArchived) "No archived chats" else "No chats yet.\nTap ＋ and scan a friend's QR.", modifier = Modifier.padding(32.dp))
            }
        } else {
            Box(Modifier.padding(pad)) {
                LazyColumn {
                    items(visible, key = { it.chatId }) { row ->
                        Row(
                            Modifier.fillMaxWidth()
                                .combinedClickable(onClick = { nav.open(row.chatId) }, onLongClick = { rowMenu = row })
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Avatar(row.title)
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text((if (row.pinned) "📌 " else "") + row.title + (if (row.muted) " 🔕" else ""), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(row.preview, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                row.time?.let { Text(fmtTime(it), style = MaterialTheme.typography.bodySmall) }
                                if (row.unread > 0) {
                                    Box(Modifier.padding(top = 4.dp).size(22.dp).background(Brand.primary, androidx.compose.foundation.shape.CircleShape), contentAlignment = Alignment.Center) {
                                        Text("${row.unread}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                        HorizontalDivider()
                    }
                }
                DropdownMenu(expanded = rowMenu != null, onDismissRequest = { rowMenu = null }) {
                    val r = rowMenu
                    if (r != null) {
                        fun flag(change: (pinned: Boolean, muted: Boolean, archived: Boolean) -> Triple<Boolean, Boolean, Boolean>) {
                            val (p, m, a) = change(r.pinned, r.muted, r.archived)
                            if (r.isGroup) g.updateGroup(r.chatId) { it.copy(pinned = p, muted = m, archived = a) }
                            else g.updateContact(r.chatId) { it.copy(pinned = p, muted = m, archived = a) }
                            rowMenu = null
                        }
                        DropdownMenuItem(text = { Text(if (r.pinned) "Unpin" else "Pin") }, onClick = { flag { p, m, a -> Triple(!p, m, a) } })
                        DropdownMenuItem(text = { Text(if (r.muted) "Unmute" else "Mute") }, onClick = { flag { p, m, a -> Triple(p, !m, a) } })
                        DropdownMenuItem(text = { Text(if (r.archived) "Unarchive" else "Archive") }, onClick = { flag { p, m, a -> Triple(p, m, !a) } })
                        if (!r.isGroup) DropdownMenuItem(text = { Text("Block") }, onClick = { g.updateContact(r.chatId) { it.copy(blocked = true) }; rowMenu = null })
                    }
                }
            }
        }
    }
}

// ======================================================================== chat

private fun queryNameMime(ctx: Context, uri: Uri): Pair<String, String> {
    var name = "file"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: "file"
    }
    return name to (ctx.contentResolver.getType(uri) ?: "application/octet-stream")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(g: Graph, chatId: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isGroup = chatId.startsWith(GROUP_PREFIX)
    val title by produceState("", chatId) {
        value = if (isGroup) g.dao.group(chatId.removePrefix(GROUP_PREFIX))?.name ?: "" else g.dao.contact(chatId)?.name ?: ""
    }
    val memberNames by produceState("", chatId) {
        if (isGroup) value = g.dao.group(chatId.removePrefix(GROUP_PREFIX))?.let { GroupInfoPayload.decode(it.info) }?.members?.joinToString(", ") { it.name } ?: ""
    }
    val messages by remember(chatId) { g.dao.messages(chatId) }.collectAsState(initial = emptyList())
    val byMsgId = remember(messages) { messages.associateBy { it.msgId } }
    var draft by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }
    var menuFor by remember { mutableStateOf<MessageEntity?>(null) }
    var forwardText by remember { mutableStateOf<String?>(null) }
    var attachMenu by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    val recorder = remember { VoiceRecorder(ctx) }
    val listState = rememberLazyListState()
    val tooLong = draft.toByteArray(Charsets.UTF_8).size > g.maxTextBytes(chatId, replyTo != null)

    DisposableEffect(chatId) { g.openChatId = chatId; onDispose { g.openChatId = null } }
    LaunchedEffect(messages.size) {
        g.markChatRead(chatId)
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { val (n, m) = queryNameMime(ctx, it); g.sendFile(chatId, it, null, n, m) }
    }
    fun toggleRecording() {
        if (!recording) recording = recorder.start()
        else { recording = false; recorder.stop()?.let { g.sendFile(chatId, null, it, "Voice note.m4a", "audio/mp4") } }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) toggleRecording() }

    Scaffold(
        topBar = {
            BrandTopBar(
                title = {
                    Column {
                        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (isGroup) Text(memberNames, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                onBack = onBack,
                actions = { if (!isGroup) TextButton(onClick = { g.startCall(chatId) }) { Text("📞", color = Color.White) } },
            )
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding()) {
                replyTo?.let { r ->
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (r.outgoing) "You" else r.senderName.ifBlank { title }, fontWeight = FontWeight.SemiBold, color = Brand.primary)
                            Text(quotePreview(r), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        TextButton(onClick = { replyTo = null }) { Text("✕") }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        TextButton(onClick = { attachMenu = true }) { Text("📎") }
                        DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                            DropdownMenuItem(text = { Text("Photo") }, onClick = { attachMenu = false; pick.launch("image/*") })
                            DropdownMenuItem(text = { Text("Video") }, onClick = { attachMenu = false; pick.launch("video/*") })
                            DropdownMenuItem(text = { Text("Document / any file") }, onClick = { attachMenu = false; pick.launch("*/*") })
                            DropdownMenuItem(text = { Text("My contact card") }, onClick = {
                                attachMenu = false
                                g.identity?.let { g.sendText(chatId, it.card(g.provider).toLink()) }
                            })
                        }
                    }
                    OutlinedTextField(
                        draft, { draft = it }, modifier = Modifier.weight(1f), enabled = !recording,
                        placeholder = { Text(if (recording) "Recording… tap ■ to send" else "Message") },
                        maxLines = 4, isError = tooLong, shape = RoundedCornerShape(24.dp),
                        supportingText = if (tooLong) ({ Text("Too long for one message") }) else null,
                    )
                    Spacer(Modifier.size(6.dp))
                    if (draft.isBlank()) {
                        Button(onClick = {
                            if (recording || ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) toggleRecording()
                            else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }, shape = androidx.compose.foundation.shape.CircleShape) { Text(if (recording) "■" else "🎙") }
                    } else {
                        Button(
                            onClick = { g.sendText(chatId, draft, replyTo?.msgId); draft = ""; replyTo = null },
                            enabled = !tooLong, shape = androidx.compose.foundation.shape.CircleShape,
                        ) { Text("➤") }
                    }
                }
            }
        },
    ) { pad ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(pad).fillMaxSize().background(Brand.chatBackground()),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(messages, key = { it.id }) { m ->
                if (m.kind == Kind.SYSTEM) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                            Text(m.text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.outgoing) Arrangement.End else Arrangement.Start) {
                        Box {
                            Bubble(g, m, m.replyTo?.let { byMsgId[it] }, isGroup, onLong = { menuFor = m })
                            DropdownMenu(expanded = menuFor?.id == m.id, onDismissRequest = { menuFor = null }) {
                                if (!m.deleted) {
                                    DropdownMenuItem(text = { Text("Reply") }, onClick = { replyTo = m; menuFor = null })
                                    if (m.kind == Kind.TEXT) {
                                        DropdownMenuItem(text = { Text("Copy") }, onClick = {
                                            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("message", m.text))
                                            menuFor = null
                                        })
                                        DropdownMenuItem(text = { Text("Forward") }, onClick = { forwardText = m.text; menuFor = null })
                                    }
                                    DropdownMenuItem(text = { Text(if (m.starred) "Unstar" else "Star") }, onClick = { g.toggleStar(m.id); menuFor = null })
                                }
                                DropdownMenuItem(text = { Text("Delete for me") }, onClick = { g.deleteForMe(m.id); menuFor = null })
                                if (m.outgoing && !m.deleted) DropdownMenuItem(text = { Text("Delete for everyone") }, onClick = { g.deleteForEveryone(m.id); menuFor = null })
                            }
                        }
                    }
                }
            }
        }
    }

    forwardText?.let { text ->
        ForwardDialog(g, text, onDone = { forwardText = null }) { target -> g.forward(text, target); Toast.makeText(ctx, "Forwarded", Toast.LENGTH_SHORT).show() }
    }
}

private fun quotePreview(m: MessageEntity) = when {
    m.deleted -> "🚫 Message deleted"
    m.kind == Kind.FILE -> "📎 ${m.fileName}"
    else -> m.text
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(g: Graph, m: MessageEntity, quoted: MessageEntity?, isGroup: Boolean, onLong: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (m.outgoing) Brand.outgoing() else MaterialTheme.colorScheme.surface,
        modifier = Modifier.widthIn(max = 300.dp).combinedClickable(onClick = {}, onLongClick = onLong),
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            if (isGroup && !m.outgoing) Text(m.senderName, fontWeight = FontWeight.SemiBold, color = Brand.primary, style = MaterialTheme.typography.labelMedium)
            if (quoted != null && !m.deleted) {
                Surface(shape = RoundedCornerShape(6.dp), color = Color.Black.copy(alpha = 0.07f), modifier = Modifier.padding(bottom = 4.dp)) {
                    Column(Modifier.padding(6.dp)) {
                        Text(if (quoted.outgoing) "You" else quoted.senderName.ifBlank { "Them" }, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                        Text(quotePreview(quoted), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            when {
                m.deleted -> Text("🚫 This message was deleted", fontStyle = FontStyle.Italic)
                m.kind == Kind.FILE -> FileContent(g, m)
                m.text.startsWith(ContactCard.LINK_PREFIX) -> {
                    val card = remember(m.text) { ContactCard.fromLink(m.text) }
                    if (card == null) Text(m.text) else Column {
                        Text("👤 Contact card: ${card.name}", fontWeight = FontWeight.SemiBold)
                        Text(card.userId, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { scope.launch { Toast.makeText(ctx, g.addContactFromLink(m.text), Toast.LENGTH_LONG).show() } }) { Text("Add contact") }
                    }
                }
                else -> Text(m.text)
            }
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                if (m.starred) Text("★ ", style = MaterialTheme.typography.labelSmall)
                Text(fmtTime(m.timestamp), style = MaterialTheme.typography.labelSmall)
                if (m.outgoing && !m.deleted) {
                    Text(
                        if (m.delivered) "  ✓✓" else "  ✓", style = MaterialTheme.typography.labelSmall,
                        color = if (m.seen) Color(0xFF1E88E5) else Color.Unspecified,
                    )
                }
            }
        }
    }
}

@Composable
private fun FileContent(g: Graph, m: MessageEntity) {
    val ctx = LocalContext.current
    val path = m.filePath
    val mime = m.fileMime ?: ""
    if (m.fileState == FileState.DONE && path != null && File(path).exists()) {
        if (mime.startsWith("image/")) {
            val bmp = remember(path) { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 4 }) }
            if (bmp != null) {
                Image(
                    bmp.asImageBitmap(), contentDescription = m.fileName, contentScale = ContentScale.Crop,
                    modifier = Modifier.width(220.dp).height(220.dp).clip(RoundedCornerShape(8.dp)).clickable { openFile(ctx, path, mime) },
                )
                return
            }
        }
        if (mime.startsWith("audio/")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    runCatching { MediaPlayer().apply { setDataSource(path); prepare(); start(); setOnCompletionListener { it.release() } } }
                }) { Text("▶") }
                Text("  ${m.fileName} · ${fmtSize(m.fileSize)}", style = MaterialTheme.typography.bodySmall)
            }
            return
        }
        Row(Modifier.clickable { openFile(ctx, path, mime) }, verticalAlignment = Alignment.CenterVertically) {
            Text("📎 ", style = MaterialTheme.typography.titleMedium)
            Column {
                Text(m.fileName ?: "File", fontWeight = FontWeight.SemiBold)
                Text("${fmtSize(m.fileSize)} · tap to open", style = MaterialTheme.typography.bodySmall)
            }
        }
        return
    }
    Column {
        Text("📎 ${m.fileName ?: "File"}", fontWeight = FontWeight.SemiBold)
        Text(fmtSize(m.fileSize), style = MaterialTheme.typography.bodySmall)
        when (m.fileState) {
            FileState.DOWNLOADING -> Text("Downloading…", style = MaterialTheme.typography.bodySmall)
            FileState.FAILED -> TextButton(onClick = { g.downloadFile(m.id) }) { Text("Failed. Retry") }
            FileState.OFFERED -> TextButton(onClick = { g.downloadFile(m.id) }) { Text("Download") }
            else -> {}
        }
    }
}

private fun openFile(ctx: Context, path: String, mime: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun ForwardDialog(g: Graph, text: String, onDone: () -> Unit, onPick: (String) -> Unit) {
    val contacts by remember { g.dao.contacts() }.collectAsState(initial = emptyList())
    val groups by remember { g.dao.groups() }.collectAsState(initial = emptyList())
    val targets = contacts.filter { !it.blocked }.map { it.userId to it.name } + groups.map { (GROUP_PREFIX + it.groupId) to it.name }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("Forward to…") },
        text = {
            LazyColumn {
                items(targets) { (id, name) ->
                    Text(name, modifier = Modifier.fillMaxWidth().clickable { onPick(id); onDone() }.padding(12.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDone) { Text("Cancel") } },
    )
}
