package com.example.meshchat.core

import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object Wire {
    const val VERSION = 1
    const val TYPE_TEXT = 1
    const val TYPE_ACK = 2
    const val TYPE_READ = 3
    const val TYPE_DELETE = 4
    const val TYPE_STATUS = 5
    const val TYPE_GROUP_INFO = 6
    const val TYPE_GROUP_TEXT = 7
    const val TYPE_FILE_OFFER = 8
    const val TYPE_CALL_INVITE = 9
    const val TYPE_CALL_ACCEPT = 10
    const val TYPE_CALL_END = 11

    /** Every packet has exactly this plaintext size, so relays cannot tell text from ack or short from long. */
    const val PLAINTEXT_SIZE = 1024
    const val EPH_LEN = 32
    const val NONCE_LEN = 12
    const val TAG_LEN = 16
    const val PACKET_SIZE = EPH_LEN + NONCE_LEN + PLAINTEXT_SIZE + TAG_LEN

    private const val INNER_HEADER = 1 + 1 + 32 + 16 + 8 + 2
    private const val SIG_LEN = 64
    const val MAX_PAYLOAD = PLAINTEXT_SIZE - INNER_HEADER - SIG_LEN
}

class InnerMessage(
    val type: Int,
    val senderEdPublic: ByteArray,
    val msgId: ByteArray,
    val timestampMs: Long,
    val payload: ByteArray,
)

/**
 * Sealed-sender packet:
 *   ephemeralX25519Pub(32) | nonce(12) | AES-256-GCM(plaintext 1024) | tag(16)
 * Outside the encryption there is NO sender, NO recipient, NO type, NO length. The sender's identity
 * and Ed25519 signature live inside; the signature also covers the recipient's key, so a packet cannot
 * be re-targeted. Only the recipient can decrypt, so only the recipient can ever raise a notification.
 *
 * Note: because the key comes from an ephemeral sender key, the *sender* cannot later re-read a packet
 * it sent (no sender-side forward secrecy trick needed: it keeps its own plaintext locally).
 */
class SealedPacketCodec(
    private val p: Curve25519Provider,
    private val rng: SecureRandom = SecureRandom(),
) {
    fun seal(
        sender: Identity,
        recipientX: ByteArray,
        type: Int,
        msgId: ByteArray,
        timestampMs: Long,
        payload: ByteArray,
    ): ByteArray {
        require(payload.size <= Wire.MAX_PAYLOAD) { "payload too large" }
        require(msgId.size == 16)
        val buf = ByteBuffer.allocate(Wire.PLAINTEXT_SIZE) // zero padded
        buf.put(Wire.VERSION.toByte()).put(type.toByte()).put(sender.edPublic).put(msgId)
            .putLong(timestampMs).putShort(payload.size.toShort()).put(payload)
        val signedLen = buf.position()
        val sig = p.sign(sender.edSeed, buf.array().copyOf(signedLen) + recipientX)
        buf.put(sig)

        val eph = p.newX25519()
        val key = deriveKey(p.x25519(eph.privateKey, recipientX), eph.publicKey, recipientX)
        val nonce = ByteArray(Wire.NONCE_LEN).also { rng.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        cipher.updateAAD(eph.publicKey)
        val ct = cipher.doFinal(buf.array())
        return eph.publicKey + nonce + ct
    }

    /** Returns null for anything that is not a valid packet addressed to [me]. Never throws. */
    fun open(me: Identity, packet: ByteArray): InnerMessage? {
        if (packet.size != Wire.PACKET_SIZE) return null
        try {
            val eph = packet.copyOfRange(0, Wire.EPH_LEN)
            val nonce = packet.copyOfRange(Wire.EPH_LEN, Wire.EPH_LEN + Wire.NONCE_LEN)
            val ct = packet.copyOfRange(Wire.EPH_LEN + Wire.NONCE_LEN, packet.size)

            val shared = try { p.x25519(me.xPrivate, eph) } catch (e: GeneralSecurityException) { return null }
            val key = deriveKey(shared, eph, me.xPublic)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            cipher.updateAAD(eph)
            val pt = try { cipher.doFinal(ct) } catch (e: GeneralSecurityException) { return null }

            val b = ByteBuffer.wrap(pt)
            if (b.get().toInt() != Wire.VERSION) return null
            val type = b.get().toInt() and 0xFF
            val senderEd = ByteArray(32).also { b.get(it) }
            val msgId = ByteArray(16).also { b.get(it) }
            val ts = b.getLong()
            val len = b.getShort().toInt() and 0xFFFF
            if (len > Wire.MAX_PAYLOAD) return null
            val payload = ByteArray(len).also { b.get(it) }
            val signedLen = b.position()
            val sig = ByteArray(64).also { b.get(it) }
            if (!p.verify(senderEd, pt.copyOf(signedLen) + me.xPublic, sig)) return null
            return InnerMessage(type, senderEd, msgId, ts, payload)
        } catch (e: RuntimeException) {
            return null
        } catch (e: GeneralSecurityException) {
            return null
        }
    }

    private fun deriveKey(shared: ByteArray, eph: ByteArray, recipientX: ByteArray): ByteArray =
        Kdf.hkdf(shared, eph, "meshchat/v1/seal".toByteArray() + recipientX, 32)
}
