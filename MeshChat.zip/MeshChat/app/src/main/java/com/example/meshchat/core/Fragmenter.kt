package com.example.meshchat.core

/** BLE characteristic writes are small (~20-500 bytes), so frames are split: [tag:2][index:1][total:1][data]. */
object Fragmenter {
    const val HEADER = 4

    fun split(frame: ByteArray, maxChunkData: Int, tag: Int): List<ByteArray> {
        require(maxChunkData > 0)
        val total = (frame.size + maxChunkData - 1) / maxChunkData
        require(total in 1..255) { "frame too large for this chunk size" }
        return List(total) { i ->
            val from = i * maxChunkData
            val to = minOf(frame.size, from + maxChunkData)
            byteArrayOf((tag shr 8).toByte(), tag.toByte(), i.toByte(), total.toByte()) + frame.copyOfRange(from, to)
        }
    }
}

class Reassembler(
    private val nowMs: () -> Long,
    private val timeoutMs: Long = 10_000,
    private val maxPartialPerPeer: Int = 8,
) {
    private class Partial(val total: Int, val startedAt: Long) {
        val parts = arrayOfNulls<ByteArray>(total)
        var count = 0
    }

    private val partials = LinkedHashMap<String, Partial>()

    /** Feed one received chunk; returns the whole frame when the last piece arrives, else null. */
    @Synchronized
    fun accept(peerId: String, chunk: ByteArray): ByteArray? {
        if (chunk.size <= Fragmenter.HEADER) return null
        val now = nowMs()
        val it = partials.entries.iterator()
        while (it.hasNext()) if (now - it.next().value.startedAt > timeoutMs) it.remove()

        val tag = ((chunk[0].toInt() and 0xFF) shl 8) or (chunk[1].toInt() and 0xFF)
        val idx = chunk[2].toInt() and 0xFF
        val total = chunk[3].toInt() and 0xFF
        if (total == 0 || idx >= total) return null

        val key = "$peerId/$tag"
        var part = partials[key]
        if (part == null) {
            val mine = partials.keys.filter { it.startsWith("$peerId/") }
            if (mine.size >= maxPartialPerPeer) partials.remove(mine.first()) // oldest first (insertion order)
            part = Partial(total, now)
            partials[key] = part
        }
        if (part.total != total) {
            partials.remove(key)
            return null
        }
        if (part.parts[idx] == null) {
            part.parts[idx] = chunk.copyOfRange(Fragmenter.HEADER, chunk.size)
            part.count++
        }
        if (part.count < part.total) return null
        partials.remove(key)
        var size = 0
        for (x in part.parts) size += x!!.size
        val out = ByteArray(size)
        var pos = 0
        for (x in part.parts) { System.arraycopy(x!!, 0, out, pos, x.size); pos += x.size }
        return out
    }
}
