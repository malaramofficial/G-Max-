package com.example.meshchat.data

import com.example.meshchat.core.PacketStore
import com.example.meshchat.core.StoredPacket

/** Carried packets live in the database, so they survive Android killing the app. Call from the router thread only. */
class RoomPacketStore(private val dao: PacketDao) : PacketStore {
    override fun put(p: StoredPacket) = dao.put(PacketEntity(p.id.joinToString("") { "%02x".format(it) }, p.id, p.bytes, p.fwdTtl, p.storedAt))
    override fun get(idHex: String): StoredPacket? = dao.get(idHex)?.toStored()
    override fun recent(n: Int): List<StoredPacket> = dao.newest(n).reversed().map { it.toStored() }
    override fun count(): Int = dao.count()
    override fun purgeOlderThan(cutoffMs: Long) = dao.purgeOlderThan(cutoffMs)
    override fun trimTo(max: Int) = dao.trimTo(max)

    private fun PacketEntity.toStored() = StoredPacket(id, bytes, fwdTtl, storedAt)
}
