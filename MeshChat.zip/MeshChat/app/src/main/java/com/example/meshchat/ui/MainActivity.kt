package com.example.meshchat.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.meshchat.Graph
import com.example.meshchat.MeshApp
import com.example.meshchat.service.MeshService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) } // so an incoming call can ring on the lock screen
        val graph = (application as MeshApp).graph
        setContent {
            val colors = if (isSystemInDarkTheme()) darkColorScheme(
                primary = Brand.primary, onPrimary = Color.White, secondary = Brand.accent,
                background = Color(0xFF0B1220), surface = Color(0xFF111C2E), onSurface = Color(0xFFE8EEF5),
            ) else lightColorScheme(
                primary = Brand.primary, onPrimary = Color.White, secondary = Brand.accent,
                background = Color(0xFFF4F7FB), surface = Color.White, onSurface = Color(0xFF172B4D),
            )
            MaterialTheme(colorScheme = colors) { App(graph) }
        }
    }
}

private sealed interface Screen {
    data object Chats : Screen
    data object Nearby : Screen
    data object Groups : Screen
    data class Chat(val chatId: String) : Screen
    data object MyCard : Screen
    data object NewGroup : Screen
    data object Status : Screen
    data object Starred : Screen
    data object Settings : Screen
}

private fun bluetoothPermissions(): List<String> =
    if (Build.VERSION.SDK_INT >= 31) listOf(
        Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT,
    ) else listOf(Manifest.permission.ACCESS_FINE_LOCATION)

/** Everything the app can use. Only Bluetooth is required to start; the rest enable files, calls, voice notes, notifications. */
private fun allPermissions(): Array<String> {
    val p = bluetoothPermissions().toMutableList()
    if (Build.VERSION.SDK_INT >= 33) { p += Manifest.permission.NEARBY_WIFI_DEVICES; p += Manifest.permission.POST_NOTIFICATIONS }
    else if (!p.contains(Manifest.permission.ACCESS_FINE_LOCATION)) p += Manifest.permission.ACCESS_FINE_LOCATION // Wi-Fi Direct on Android 12L and below
    p += Manifest.permission.RECORD_AUDIO
    return p.toTypedArray()
}

private fun hasBluetoothPermissions(ctx: Context) =
    bluetoothPermissions().all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

private fun startMesh(ctx: Context) =
    ContextCompat.startForegroundService(ctx, Intent(ctx, MeshService::class.java))

@Composable
private fun App(g: Graph) {
    val ctx = LocalContext.current
    var identity by remember { mutableStateOf(g.identity) }
    var screen by remember { mutableStateOf<Screen>(Screen.Chats) }

    val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasBluetoothPermissions(ctx)) startMesh(ctx)
    }
    LaunchedEffect(identity) {
        if (identity != null) {
            if (hasBluetoothPermissions(ctx)) startMesh(ctx) else permissions.launch(allPermissions())
        }
    }
    LaunchedEffect(Unit) { g.toasts.collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() } }

    if (identity == null) {
        OnboardingScreen(g, onDone = { name -> identity = g.createIdentity(name) }, onRestored = { identity = g.identity })
        return
    }

    val nav = remember {
        Nav(
            open = { screen = Screen.Chat(it) }, myCard = { screen = Screen.MyCard }, newGroup = { screen = Screen.NewGroup },
            status = { screen = Screen.Status }, starred = { screen = Screen.Starred }, settings = { screen = Screen.Settings },
        )
    }
    val isMainTab = screen == Screen.Chats || screen == Screen.Nearby || screen == Screen.Groups || screen == Screen.Settings
    BackHandler(enabled = screen != Screen.Chats) { screen = Screen.Chats }
    Scaffold(
        bottomBar = {
            if (isMainTab) NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val tabs = listOf(
                    Triple(Screen.Chats, "Chats", "💬"),
                    Triple(Screen.Nearby, "Nearby", "📡"),
                    Triple(Screen.Groups, "Groups", "👥"),
                    Triple(Screen.Settings, "Settings", "⚙"),
                )
                tabs.forEach { (target, label, glyph) ->
                    NavigationBarItem(
                        selected = screen == target,
                        onClick = { screen = target },
                        icon = { Text(glyph) },
                        label = { Text(label) },
                    )
                }
            }
        },
    ) { contentPadding ->
        Box(Modifier.padding(contentPadding)) {
            when (val s = screen) {
                Screen.Chats -> ChatListScreen(g, nav)
                Screen.Nearby -> NearbyScreen(g, onMyCard = nav.myCard)
                Screen.Groups -> GroupsScreen(g, nav)
                is Screen.Chat -> ChatScreen(g, s.chatId, onBack = { screen = Screen.Chats })
                Screen.MyCard -> MyCardScreen(g, onBack = { screen = Screen.Chats })
                Screen.NewGroup -> NewGroupScreen(g, onBack = { screen = Screen.Chats }, onCreated = { screen = Screen.Groups })
                Screen.Status -> StatusScreen(g, onBack = { screen = Screen.Chats })
                Screen.Starred -> StarredScreen(g, onBack = { screen = Screen.Chats })
                Screen.Settings -> SettingsScreen(g, onBack = { screen = Screen.Chats })
            }
            CallOverlay(g)
        }
    }
}
