package com.example.meshchat.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.example.meshchat.MeshApp

/** Keeps the BLE mesh alive while the app is in the background. Started only after permissions are granted. */
class MeshService : Service() {
    override fun onCreate() {
        super.onCreate()
        ServiceCompat.startForeground(
            this, 1, Notifier.serviceNotification(this),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0,
        )
        (application as MeshApp).graph.startMesh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        (application as MeshApp).graph.stopMesh()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
