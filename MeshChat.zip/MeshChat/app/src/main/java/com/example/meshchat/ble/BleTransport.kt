package com.example.meshchat.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.os.SystemClock
import com.example.meshchat.core.Fragmenter
import com.example.meshchat.core.MeshTransport
import com.example.meshchat.core.Reassembler
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** How long to scan / sleep, chosen from battery state. Scanning is the main battery cost of a BLE mesh. */
object BatteryPolicy {
    class Window(val onMs: Long, val offMs: Long)

    fun scanWindow(ctx: Context): Window {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return when {
            charging -> Window(10_000, 10_000)
            level > 50 -> Window(5_000, 20_000)
            level > 20 -> Window(4_000, 40_000)
            else -> Window(3_000, 90_000)
        }
    }
}

/**
 * BLE link layer: every phone is both a GATT server (advertises, receives writes, notifies) and,
 * when it has the lower random tag of a pair, a GATT client. One connection per pair carries both
 * directions: client writes -> RX characteristic, server notifies -> TX characteristic.
 * Frames are split into chunks by [Fragmenter]. Large media should later go over Wi-Fi Direct/Aware.
 *
 * NOT yet compiled or run on a device in this build session: treat as a first draft to test on 2+ phones.
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleTransport(private val ctx: Context) : MeshTransport {

    /** User setting: scan far less often (a few seconds every ~90 s) to save battery. */
    @Volatile var lowPower = false
    var onFrame: (peerId: String, frame: ByteArray) -> Unit = { _, _ -> }
    var onPeerUp: (peerId: String) -> Unit = {}
    var onPeerDown: (peerId: String) -> Unit = {}

    private val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter = mgr.adapter
    private val handler = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()
    private val myTag = ByteArray(4).also { rng.nextBytes(it) }
    private val reassembler = Reassembler({ SystemClock.elapsedRealtime() })
    private val links = ConcurrentHashMap<String, Link>()
    private val connecting = ConcurrentHashMap.newKeySet<String>()
    private val serverMtu = ConcurrentHashMap<String, Int>()
    private val clientMtu = ConcurrentHashMap<String, Int>()
    private val clientRx = ConcurrentHashMap<String, BluetoothGattCharacteristic>()
    private var server: BluetoothGattServer? = null
    @Volatile private var running = false
    @Volatile private var scanning = false

    // ---------------- MeshTransport ----------------

    override fun peers(): Collection<String> = links.keys.toList()

    override fun send(peerId: String, frame: ByteArray) {
        val link = links[peerId] ?: return
        link.enqueue(Fragmenter.split(frame, link.chunkData, rng.nextInt(65536)))
    }

    // ---------------- lifecycle ----------------

    fun start() {
        if (running || adapter == null || !adapter.isEnabled) return
        running = true
        startServer()
        startAdvertising()
        handler.post(::scanCycle)
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        stopScan()
        runCatching { adapter?.bluetoothLeAdvertiser?.stopAdvertising(advCb) }
        links.values.forEach { it.close() }
        links.clear(); connecting.clear()
        runCatching { server?.close() }
        server = null
    }

    // ---------------- per-link send queue ----------------

    private abstract inner class Link(val id: String) {
        @Volatile var mtu = 23
        val chunkData: Int get() = (mtu - 3 - Fragmenter.HEADER).coerceAtLeast(16)
        private val queue = ArrayDeque<ByteArray>()
        private var busy = false

        @Synchronized fun enqueue(chunks: List<ByteArray>) { queue.addAll(chunks); pump() }
        @Synchronized fun onSent() { busy = false; pump() }

        private fun pump() {
            if (busy) return
            val next = queue.removeFirstOrNull() ?: return
            busy = true
            if (!write(next)) { busy = false; queue.clear() }
        }

        abstract fun write(chunk: ByteArray): Boolean
        abstract fun close()
    }

    private inner class ServerLink(val device: BluetoothDevice) : Link("s:${device.address}") {
        override fun write(chunk: ByteArray): Boolean {
            val srv = server ?: return false
            val ch = srv.getService(SERVICE_UUID)?.getCharacteristic(TX_UUID) ?: return false
            ch.value = chunk
            return srv.notifyCharacteristicChanged(device, ch, false)
        }
        override fun close() { runCatching { server?.cancelConnection(device) } }
    }

    private inner class ClientLink(val gatt: BluetoothGatt, val rx: BluetoothGattCharacteristic) : Link("c:${gatt.device.address}") {
        override fun write(chunk: ByteArray): Boolean {
            rx.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            rx.value = chunk
            return gatt.writeCharacteristic(rx)
        }
        override fun close() { runCatching { gatt.disconnect() } }
    }

    // ---------------- GATT server (receives from / notifies peers) ----------------

    private fun startServer() {
        val svc = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val rx = BluetoothGattCharacteristic(
            RX_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE,
        )
        val tx = BluetoothGattCharacteristic(TX_UUID, BluetoothGattCharacteristic.PROPERTY_NOTIFY, BluetoothGattCharacteristic.PERMISSION_READ)
        tx.addDescriptor(BluetoothGattDescriptor(CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        svc.addCharacteristic(rx)
        svc.addCharacteristic(tx)
        server = mgr.openGattServer(ctx, serverCb).also { it.addService(svc) }
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            val id = "s:${device.address}"
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                serverMtu.remove(device.address)
                links.remove(id)?.let { onPeerDown(id) }
            } else if (newState == BluetoothProfile.STATE_CONNECTED && links.size >= MAX_LINKS) {
                server?.cancelConnection(device)
            }
        }

        override fun onMtuChanged(device: BluetoothDevice, mtu: Int) {
            serverMtu[device.address] = mtu
            links["s:${device.address}"]?.mtu = mtu
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray,
        ) {
            if (characteristic.uuid == RX_UUID) {
                val id = "s:${device.address}"
                reassembler.accept(id, value)?.let { onFrame(id, it) }
            }
            if (responseNeeded) server?.sendResponse(device, requestId, android.bluetooth.BluetoothGatt.GATT_SUCCESS, 0, null)
        }

        override fun onDescriptorWriteRequest(
            device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray,
        ) {
            if (descriptor.uuid == CCCD && value.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                val link = ServerLink(device).also { it.mtu = serverMtu[device.address] ?: 23 }
                links[link.id] = link
                onPeerUp(link.id)
            }
            if (responseNeeded) server?.sendResponse(device, requestId, android.bluetooth.BluetoothGatt.GATT_SUCCESS, 0, null)
        }

        override fun onNotificationSent(device: BluetoothDevice, status: Int) {
            links["s:${device.address}"]?.onSent()
        }
    }

    // ---------------- GATT client (we dial peers with a higher tag) ----------------

    private val clientCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            val addr = gatt.device.address
            val id = "c:$addr"
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt.requestMtu(247)
            } else {
                connecting.remove(addr); clientMtu.remove(addr); clientRx.remove(addr)
                links.remove(id)?.let { onPeerDown(id) }
                gatt.close()
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) clientMtu[gatt.device.address] = mtu
            gatt.discoverServices()
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val svc = gatt.getService(SERVICE_UUID)
            val rx = svc?.getCharacteristic(RX_UUID)
            val tx = svc?.getCharacteristic(TX_UUID)
            val cccd = tx?.getDescriptor(CCCD)
            if (rx == null || tx == null || cccd == null) { gatt.disconnect(); return }
            clientRx[gatt.device.address] = rx
            gatt.setCharacteristicNotification(tx, true)
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(cccd)
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            val addr = gatt.device.address
            val rx = clientRx[addr]
            if (status != BluetoothGatt.GATT_SUCCESS || rx == null) { gatt.disconnect(); return }
            val link = ClientLink(gatt, rx).also { it.mtu = clientMtu[addr] ?: 23 }
            connecting.remove(addr)
            links[link.id] = link
            onPeerUp(link.id)
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid != TX_UUID) return
            val id = "c:${gatt.device.address}"
            reassembler.accept(id, characteristic.value)?.let { onFrame(id, it) }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            links["c:${gatt.device.address}"]?.onSent()
        }
    }

    // ---------------- advertising + duty-cycled scanning ----------------

    private val advCb = object : AdvertiseCallback() {}

    private fun startAdvertising() {
        val adv = adapter.bluetoothLeAdvertiser ?: return
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_POWER)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true).setTimeout(0).build()
        val data = AdvertiseData.Builder().setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        // 128-bit UUID leaves no room for the tag in the main packet, so it rides in the scan response.
        val scanResponse = AdvertiseData.Builder().setIncludeDeviceName(false)
            .addServiceData(ParcelUuid(SERVICE_UUID), myTag).build()
        adv.startAdvertising(settings, data, scanResponse, advCb)
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val tag = result.scanRecord?.getServiceData(ParcelUuid(SERVICE_UUID)) ?: return
            if (tag.size != 4) return
            val addr = result.device.address
            if (links.containsKey("c:$addr") || connecting.contains(addr)) return
            if (links.size + connecting.size >= MAX_LINKS) return
            // Only the device with the lower tag dials, so a pair never ends up with two connections.
            if (compareUnsigned(myTag, tag) >= 0) return
            connecting.add(addr)
            result.device.connectGatt(ctx, false, clientCb, BluetoothDevice.TRANSPORT_LE)
        }
    }

    private fun scanCycle() {
        if (!running) return
        val w = if (lowPower) BatteryPolicy.Window(3_000, 90_000) else BatteryPolicy.scanWindow(ctx)
        if (links.size + connecting.size < MAX_LINKS) {
            startScan()
            handler.postDelayed({ stopScan(); handler.postDelayed(::scanCycle, w.offMs) }, w.onMs)
        } else {
            handler.postDelayed(::scanCycle, w.offMs)
        }
    }

    private fun startScan() {
        if (scanning) return
        val scanner = adapter.bluetoothLeScanner ?: return
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_POWER).build()
        scanner.startScan(listOf(filter), settings, scanCb)
        scanning = true
    }

    private fun stopScan() {
        if (!scanning) return
        runCatching { adapter.bluetoothLeScanner?.stopScan(scanCb) }
        scanning = false
    }

    private fun compareUnsigned(a: ByteArray, b: ByteArray): Int {
        for (i in a.indices) {
            val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)
            if (d != 0) return d
        }
        return 0
    }

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("7d1c0a10-3b5e-4c52-9a7e-5d2f1c0b6a01")
        val RX_UUID: UUID = UUID.fromString("7d1c0a11-3b5e-4c52-9a7e-5d2f1c0b6a01")
        val TX_UUID: UUID = UUID.fromString("7d1c0a12-3b5e-4c52-9a7e-5d2f1c0b6a01")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        const val MAX_LINKS = 4
    }
}
