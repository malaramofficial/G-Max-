package com.example.meshchat.core

import java.security.SecureRandom
import java.util.Collections
import java.util.Random

class Contact(val edPublic: ByteArray, val xPublic: ByteArray, val name: String) {
    val userId: String get() = UserId.derive(edPublic, xPublic)
}

interface ContactDirectory {
    /** Only contacts the user has accepted. Messages from anyone else are silently dropped. */
    fun findAccepted(edPublic: ByteArray): Contact?
}

interface MeshTransport {
    /** Currently connected neighbours (opaque ids: BLE address ...). */
    fun peers(): Collection<String>
    fun send(peerId: String, frame: ByteArray)
}

interface Scheduler {
    fun postDelayed(delayMs: Long, task: () -> Unit)
}

interface MeshEvents {
    /**
     * Called ONLY on the real recipient, for every message type except delivery receipts.
     * This is the single place a notification may be raised.
     */
    fun onInbound(from: Contact, type: Int, msgId: ByteArray, timestampMs: Long, payload: ByteArray)
    fun onDelivered(to: Contact, msgId: ByteArray)
}

class MeshConfig(
    val maxStored: Int = 500,
    val storeTtlMs: Long = 24L * 60 * 60 * 1000,
    val jitterMinMs: Int = 50,
    val jitterMaxMs: Int = 400,
    val initialTtlMin: Int = 6,
    val initialTtlMax: Int = 10,
    val seenCapacity: Int = 4096,
    val haveLimit: Int = 64,
    /**
     * true  = the real recipient forwards the packet like everyone else, so neighbours cannot tell
     *         who it was for (more privacy, a little more radio use).
     * false = the recipient stops forwarding (saves battery, but "the one who didn't forward" is the recipient).
     */
    val relayOwnPackets: Boolean = true,
)

/**
 * Store-and-forward flooding mesh. A relay sees only fixed-size opaque blobs: it cannot read them,
 * cannot tell who they are for, shows no UI/notification, and delays each forward by a random jitter.
 */
class MeshRouter(
    private val me: Identity,
    private val codec: SealedPacketCodec,
    private val contacts: ContactDirectory,
    private val transport: MeshTransport,
    private val scheduler: Scheduler,
    private val events: MeshEvents,
    private val nowMs: () -> Long,
    private val rng: Random = SecureRandom(),
    private val config: MeshConfig = MeshConfig(),
    private val store: PacketStore = InMemoryPacketStore(),
) {
    private val seen = lruSet(config.seenCapacity)
    private val delivered = lruSet(config.seenCapacity)

    @Synchronized
    fun storedCount(): Int = store.count()

    /** Queue + broadcast a text message. Returns its message id (use it to match the delivery receipt). */
    @Synchronized
    fun sendText(to: Contact, text: String, replyTo: ByteArray? = null): ByteArray =
        send(to, Wire.TYPE_TEXT, TextPayload(text, replyTo).encode())

    /** Seal + broadcast any message type. Pass [msgId] to reuse one id for several recipients (group fan-out). */
    @Synchronized
    fun send(to: Contact, type: Int, payload: ByteArray, msgId: ByteArray? = null): ByteArray {
        require(payload.size <= Wire.MAX_PAYLOAD) { "message too long (max ${Wire.MAX_PAYLOAD} bytes)" }
        return originate(to, type, payload, msgId)
    }

    @Synchronized
    fun onPeerConnected(peerId: String) {
        purgeExpired()
        val ids = store.recent(config.haveLimit).map { it.id }
        if (ids.isEmpty()) return
        safeSend(peerId, idListFrame(F_HAVE, ids))
    }

    @Synchronized
    fun onFrame(peerId: String, frame: ByteArray) {
        try {
            if (frame.isEmpty()) return
            when (frame[0].toInt()) {
                F_PACKET -> {
                    if (frame.size != 2 + Wire.PACKET_SIZE) return
                    val ttl = frame[1].toInt() and 0xFF
                    if (ttl < 1 || ttl > MAX_TTL) return
                    handlePacket(peerId, ttl, frame.copyOfRange(2, frame.size))
                }
                F_HAVE -> onHave(peerId, frame)
                F_WANT -> onWant(peerId, frame)
            }
        } catch (e: RuntimeException) {
            // Malformed data from the air must never crash the router.
        }
    }

    @Synchronized
    fun purgeExpired() {
        store.purgeOlderThan(nowMs() - config.storeTtlMs)
    }

    // ---- internals ----

    private fun originate(to: Contact, type: Int, payload: ByteArray, givenId: ByteArray?): ByteArray {
        purgeExpired()
        val msgId = givenId ?: ByteArray(16).also { rng.nextBytes(it) }
        val pkt = codec.seal(me, to.xPublic, type, msgId, nowMs(), payload)
        val ttl = config.initialTtlMin + rng.nextInt(config.initialTtlMax - config.initialTtlMin + 1)
        val id = packetId(pkt)
        seen.add(id.toHex())
        remember(id, pkt, ttl)
        val frame = packetFrame(ttl, pkt)
        for (peer in transport.peers().toList()) safeSend(peer, frame)
        return msgId
    }

    private fun handlePacket(from: String, ttl: Int, bytes: ByteArray) {
        val id = packetId(bytes)
        if (!seen.add(id.toHex())) return

        val inner = codec.open(me, bytes)
        if (inner != null) {
            val sender = contacts.findAccepted(inner.senderEdPublic)
            if (sender != null && delivered.add(inner.msgId.toHex())) {
                if (inner.type == Wire.TYPE_ACK) {
                    if (inner.payload.size == 16) events.onDelivered(sender, inner.payload)
                } else {
                    events.onInbound(sender, inner.type, inner.msgId, inner.timestampMs, inner.payload)
                    if (inner.type in ACKED_TYPES) originate(sender, Wire.TYPE_ACK, inner.msgId, null) // delivery receipt
                }
            }
            if (!config.relayOwnPackets) return
        }

        if (ttl > 1) {
            val fwd = ttl - 1
            remember(id, bytes, fwd)
            scheduleForward(id.toHex(), fwd, from)
        }
    }

    private fun scheduleForward(idHex: String, ttl: Int, except: String?) {
        val span = config.jitterMaxMs - config.jitterMinMs + 1
        val delay = (config.jitterMinMs + rng.nextInt(span)).toLong()
        scheduler.postDelayed(delay) {
            synchronized(this@MeshRouter) {
                val s = store.get(idHex) ?: return@postDelayed
                val frame = packetFrame(ttl, s.bytes)
                for (peer in transport.peers().toList()) if (peer != except) safeSend(peer, frame)
            }
        }
    }

    private fun onHave(peerId: String, frame: ByteArray) {
        val ids = parseIdList(frame) ?: return
        val want = ids.filter { !seen.contains(it.toHex()) }.take(config.haveLimit)
        if (want.isNotEmpty()) safeSend(peerId, idListFrame(F_WANT, want))
    }

    private fun onWant(peerId: String, frame: ByteArray) {
        val ids = parseIdList(frame) ?: return
        for (id in ids) {
            val s = store.get(id.toHex()) ?: continue
            safeSend(peerId, packetFrame(s.fwdTtl, s.bytes))
        }
    }

    private fun remember(id: ByteArray, bytes: ByteArray, fwdTtl: Int) {
        store.put(StoredPacket(id, bytes, fwdTtl, nowMs()))
        store.trimTo(config.maxStored)
    }

    private fun safeSend(peer: String, frame: ByteArray) {
        try { transport.send(peer, frame) } catch (e: RuntimeException) { /* peer went away */ }
    }

    private fun packetFrame(ttl: Int, pkt: ByteArray) = byteArrayOf(F_PACKET.toByte(), ttl.toByte()) + pkt

    private fun idListFrame(type: Int, ids: List<ByteArray>): ByteArray {
        val out = ByteArray(2 + ids.size * ID_LEN)
        out[0] = type.toByte(); out[1] = ids.size.toByte()
        ids.forEachIndexed { i, id -> System.arraycopy(id, 0, out, 2 + i * ID_LEN, ID_LEN) }
        return out
    }

    private fun parseIdList(frame: ByteArray): List<ByteArray>? {
        if (frame.size < 2) return null
        val n = frame[1].toInt() and 0xFF
        if (frame.size != 2 + n * ID_LEN) return null
        return List(n) { frame.copyOfRange(2 + it * ID_LEN, 2 + (it + 1) * ID_LEN) }
    }

    companion object {
        const val F_PACKET = 1
        const val F_HAVE = 2
        const val F_WANT = 3
        const val ID_LEN = 8
        const val MAX_TTL = 16

        /** Message types that get an automatic delivery receipt. Calls and read-receipts do not. */
        val ACKED_TYPES = setOf(
            Wire.TYPE_TEXT, Wire.TYPE_GROUP_TEXT, Wire.TYPE_GROUP_INFO,
            Wire.TYPE_FILE_OFFER, Wire.TYPE_STATUS, Wire.TYPE_DELETE,
        )

        fun packetId(packet: ByteArray): ByteArray = Kdf.sha256(packet).copyOf(ID_LEN)

        private fun lruSet(cap: Int): MutableSet<String> = Collections.newSetFromMap(
            object : LinkedHashMap<String, Boolean>(16, 0.75f, true) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > cap
            }
        )
    }
}
