#!/usr/bin/env bash
# Compile the pure-Kotlin core (no Android SDK needed) and run its self-test.
set -euo pipefail
cd "$(dirname "$0")"

# The old script assumed Gradle lived at /opt/gradle. GitHub Actions and Android Studio
# install Gradle elsewhere, so resolve the Kotlin compiler jars from Gradle's dependency cache.
GRADLE_BIN="$(command -v gradle || true)"
GRADLE_ROOT=""
if [[ -n "$GRADLE_BIN" ]]; then
  GRADLE_ROOT="$(dirname "$(dirname "$(readlink -f "$GRADLE_BIN")")")"
fi
L="${GRADLE_LIB:-}"
if [[ -z "$L" || ! -f "$L/kotlin-compiler-embeddable-2.0.21.jar" ]]; then
  L="$(mktemp -d "${TMPDIR:-/tmp}/meshchat-gradle-lib.XXXXXX")"
  CACHE_ROOT="${GRADLE_USER_HOME:-$HOME/.gradle}/caches/modules-2/files-2.1"
  SEARCH_ROOTS=()
  [[ -d "$CACHE_ROOT" ]] && SEARCH_ROOTS+=("$CACHE_ROOT")
  [[ -n "$GRADLE_ROOT" && -d "$GRADLE_ROOT/lib" ]] && SEARCH_ROOTS+=("$GRADLE_ROOT/lib")
  if [[ ${#SEARCH_ROOTS[@]} -eq 0 ]]; then
    echo "Could not find Gradle dependency cache or Gradle installation." >&2
    exit 2
  fi
  for pattern in \
    "kotlin-compiler-embeddable-2.0.21.jar" \
    "kotlin-stdlib-2.0.21.jar" \
    "kotlin-script-runtime-2.0.21.jar" \
    "kotlin-daemon-embeddable-2.0.21.jar" \
    "trove4j*.jar" "annotations-*.jar" "kotlinx-coroutines-core-jvm-*.jar"; do
    found=""
    for root in "${SEARCH_ROOTS[@]}"; do
      found="$(find "$root" -type f -name "$pattern" -print -quit 2>/dev/null || true)"
      [[ -n "$found" ]] && break
    done
    [[ -n "$found" ]] && cp "$found" "$L/"
  done
fi

required=(
  kotlin-compiler-embeddable-2.0.21.jar
  kotlin-stdlib-2.0.21.jar
  kotlin-script-runtime-2.0.21.jar
  kotlin-daemon-embeddable-2.0.21.jar
)
for jar in "${required[@]}"; do
  if [[ ! -f "$L/$jar" ]]; then
    echo "Missing $jar. Set GRADLE_LIB to a directory containing the Kotlin 2.0.21 compiler jars." >&2
    exit 2
  fi
done

KCP="$L/kotlin-compiler-embeddable-2.0.21.jar:$L/kotlin-stdlib-2.0.21.jar:$L/kotlin-script-runtime-2.0.21.jar:$L/kotlin-daemon-embeddable-2.0.21.jar"
[[ -f "$L/kotlin-reflect-2.0.21.jar" ]] && KCP="$KCP:$L/kotlin-reflect-2.0.21.jar"
for jar in "$L"/trove4j*.jar "$L"/annotations-*.jar "$L"/kotlinx-coroutines-core-jvm-*.jar; do
  [[ -f "$jar" ]] && KCP="$KCP:$jar"
done

OUT="${TMPDIR:-/tmp}/meshchat-core-out"
rm -rf "$OUT"; mkdir -p "$OUT"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect \
  -cp "$L/kotlin-stdlib-2.0.21.jar" -jvm-target 17 -d "$OUT" \
  ../app/src/main/java/com/example/meshchat/core/*.kt ./*.kt
java -cp "$OUT:$L/kotlin-stdlib-2.0.21.jar" verify.CoreVerifyKt
