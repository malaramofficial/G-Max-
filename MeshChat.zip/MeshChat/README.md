# MeshChat — offline, WhatsApp-style chat over Bluetooth LE mesh + Wi-Fi Direct

Status: **v0.2 feature-complete draft, not yet run on phones.**

## What is verified, what is not

| Part | Where | State |
|---|---|---|
| ID + QR card, sealed-sender encryption, mesh router, store-and-forward + restart persistence, groups, payload formats, file transfer (encrypted TCP), call-audio encryption + UDP pipe, passphrase backup | `app/.../core/` (pure Kotlin) | **Compiled and tested**: `core-verify/run.sh` -> 70/70 checks pass |
| Tink crypto, KeyVault, Room DB, BLE transport, Wi-Fi Direct, call engine (audio), voice notes, service, all screens | everything else in `app/` | **Written, never compiled or run** (no Android SDK / Maven access where it was written). Expect compile errors to fix on first build and device quirks (BLE, Wi-Fi Direct, audio). |

## Features
- Own unique ID per user (keys, no phone number / server), add friends by scanning QR
- 1-to-1 chat, replies, forward, copy, star, delete for me / for everyone, ✓ sent, ✓✓ delivered, blue ✓✓ seen (switchable)
- Groups up to 8 people (each message is a separate sealed packet per member)
- Photos, videos, documents, voice notes: offer travels over the mesh, bytes over Wi-Fi (same Wi-Fi, or Wi-Fi Direct group, Android 10+)
- Voice calls over Wi-Fi (same Wi-Fi or Wi-Fi Direct), end-to-end encrypted; call log in the chat
- Status (24 h text), pin / mute / archive / block, starred messages, dark mode
- Private mesh: relays cannot read, cannot tell who a packet is for, show nothing, add random delay
- Battery: duty-cycled BLE scanning by battery level + optional Battery saver, Wi-Fi only on demand
- Encrypted backup/restore of the ID and contacts (passphrase)
- Carried packets survive the app being killed (stored in Room)

## Build
Open in Android Studio (JDK 17), sync, run on a real phone. Bluetooth LE does not work on the emulator; you need **2+ phones**.
Core tests (no Android needed): `core-verify/run.sh`

## Not built (be upfront with users)
- **Video calls**, group calls, location sharing, stickers/GIFs, typing indicator (costs battery), WhatsApp Web, payments, channels, phone-number login
- Calls and files cannot hop across the BLE mesh: both phones must be within Wi-Fi range of each other
- Group members who are not your contacts become hidden contacts (so their group messages can reach you)
- Status goes to your first 30 contacts; groups are capped at 8
- One message = max ~900 bytes (~300 Hindi characters); longer text, send as a file
- Backup does not include chat history; uninstalling without a backup loses the ID
- File offers are valid only while the sender's app is running (the file server is in memory)
- INTERNET permission is declared only because Android requires it for local sockets; the app never uses the internet

## Known limits of the privacy design
- A radio sniffer can see *that* traffic exists, not what or who. Cover traffic would hide that but costs battery.
- Every phone trial-decrypts every packet it sees (that is how recipients stay hidden); a little CPU per packet.
- Android may still show the system "Wi-Fi Direct" activity or briefly drop normal Wi-Fi while joining a group.
