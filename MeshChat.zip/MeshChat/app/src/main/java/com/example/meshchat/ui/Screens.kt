package com.example.meshchat.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.meshchat.Graph
import com.example.meshchat.call.CallState
import com.example.meshchat.core.GroupInfoPayload
import com.example.meshchat.data.ChatDao
import com.example.meshchat.data.GROUP_PREFIX
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Brand {
    val primary = Color(0xFF102A43)
    val accent = Color(0xFF12A895)
    @Composable fun outgoing() = if (androidx.compose.foundation.isSystemInDarkTheme()) Color(0xFF144D37) else Color(0xFFD7F5E0)
    @Composable fun chatBackground() = if (androidx.compose.foundation.isSystemInDarkTheme()) Color(0xFF0B141A) else Color(0xFFEFEAE2)
}

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
private val dayFmt = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
fun fmtTime(ms: Long): String = timeFmt.format(Date(ms))
fun fmtDay(ms: Long): String = dayFmt.format(Date(ms))
fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    else -> "%.1f MB".format(b / 1048576.0)
}

@Composable
fun Avatar(name: String, size: Int = 48) {
    Box(Modifier.size(size.dp).background(Brand.primary.copy(alpha = 0.85f), CircleShape), contentAlignment = Alignment.Center) {
        Text(name.firstOrNull()?.uppercase() ?: "?", color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrandTopBar(title: @Composable () -> Unit, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = title,
        navigationIcon = { if (onBack != null) TextButton(onClick = onBack) { Text("←", color = Color.White) } },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Brand.primary, titleContentColor = Color.White, actionIconContentColor = Color.White),
    )
}

@Composable
fun PassphraseDialog(title: String, hint: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(hint, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(pass, { pass = it }, singleLine = true, label = { Text("Passphrase (8+ characters)") }, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pass) }, enabled = pass.length >= 8) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ======================================================================== onboarding

@Composable
fun OnboardingScreen(g: Graph, onDone: (String) -> Unit, onRestored: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { restoreUri = it }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.Start,
    ) {
        Surface(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = Brand.primary) {
            Column(Modifier.padding(24.dp)) {
                Text("M", style = MaterialTheme.typography.headlineLarge, color = Brand.accent, fontWeight = FontWeight.Black)
                Text("MeshChat", style = MaterialTheme.typography.headlineLarge, color = Color.White, fontWeight = FontWeight.Bold)
                Text("Private conversations. Nearby connections.", color = Color.White.copy(alpha = 0.86f))
            }
        }
        Spacer(Modifier.size(28.dp))
        Text("Create your profile", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.size(6.dp))
        Text("Choose a name to create your private MeshChat identity. No phone number or account is required.")
        Spacer(Modifier.size(20.dp))
        OutlinedTextField(name, { name = it.take(30) }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.size(16.dp))
        Button(onClick = { onDone(name.trim()) }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create my ID") }
        OutlinedButton(onClick = { openBackup.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Restore my ID from a backup") }
        Spacer(Modifier.size(16.dp))
        Text("Your identity keys stay on this device. Share your QR code only with people you trust.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    restoreUri?.let { uri ->
        PassphraseDialog("Restore backup", "Enter the passphrase you chose when you made the backup.", onDismiss = { restoreUri = null }, onConfirm = { pass ->
            restoreUri = null
            scope.launch {
                val data = runCatching { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }.getOrNull()
                val ok = data != null && g.importBackup(data, pass)
                Toast.makeText(ctx, if (ok) "ID restored" else "Wrong passphrase or not a MeshChat backup", Toast.LENGTH_LONG).show()
                if (ok) onRestored()
            }
        })
    }
}

// ======================================================================== my ID / add friend

@Composable
fun MyCardScreen(g: Graph, onBack: () -> Unit) {
    val me = g.identity ?: return
    val link = remember(me) { me.card(g.provider).toLink() }
    val qr = remember(link) { qrBitmap(link) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val scan = rememberLauncherForActivityResult(ScanContract()) { res ->
        res.contents?.let { text -> scope.launch { Toast.makeText(ctx, g.addContactFromLink(text), Toast.LENGTH_LONG).show() } }
    }
    Scaffold(topBar = { BrandTopBar({ Text("My ID") }, onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(me.name, style = MaterialTheme.typography.titleLarge)
            Text(me.userId, style = MaterialTheme.typography.titleMedium, color = Brand.primary)
            Spacer(Modifier.size(16.dp))
            Image(qr.asImageBitmap(), contentDescription = "My QR code", modifier = Modifier.size(260.dp))
            Spacer(Modifier.size(16.dp))
            Button(onClick = {
                scan.launch(ScanOptions().setPrompt("Scan your friend's MeshChat QR").setBeepEnabled(false).setOrientationLocked(false))
            }) { Text("Scan a friend's QR") }
            Spacer(Modifier.size(12.dp))
            Text(
                "Both of you scan each other's QR once. After that you can chat whenever you are near each other " +
                    "(or through other MeshChat phones in between, who cannot read anything).",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

private fun qrBitmap(text: String, size: Int = 600): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
    return bmp
}

// ======================================================================== new group

@Composable
fun NewGroupScreen(g: Graph, onBack: () -> Unit, onCreated: () -> Unit) {
    val ctx = LocalContext.current
    val contacts by remember { g.dao.contacts() }.collectAsState(initial = emptyList())
    val usable = contacts.filter { it.accepted && !it.blocked }
    val selected = remember { mutableStateListOf<String>() }
    var name by remember { mutableStateOf("") }
    val canCreate = name.isNotBlank() && selected.size in 2..7

    Scaffold(topBar = { BrandTopBar({ Text("New group") }, onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(name, { name = it.take(40) }, label = { Text("Group name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Pick 2 to 7 friends (groups are limited to 8 people including you)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(usable, key = { it.userId }) { c ->
                    Row(Modifier.fillMaxWidth().clickable { if (c.userId in selected) selected.remove(c.userId) else selected.add(c.userId) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = c.userId in selected, onCheckedChange = null)
                        Spacer(Modifier.size(8.dp))
                        Avatar(c.name, 36)
                        Text(c.name, modifier = Modifier.padding(start = 12.dp))
                    }
                }
            }
            Button(
                onClick = { if (g.createGroup(name, selected.toList())) onCreated() else Toast.makeText(ctx, "Could not create the group", Toast.LENGTH_SHORT).show() },
                enabled = canCreate, modifier = Modifier.fillMaxWidth(),
            ) { Text("Create group") }
        }
    }
}

// ======================================================================== status

@Composable
fun StatusScreen(g: Graph, onBack: () -> Unit) {
    val since = remember { System.currentTimeMillis() - 24L * 60 * 60 * 1000 }
    val statuses by remember { g.dao.statuses(since) }.collectAsState(initial = emptyList())
    var draft by remember { mutableStateOf("") }
    Scaffold(topBar = { BrandTopBar({ Text("Status") }, onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            OutlinedTextField(draft, { draft = it.take(250) }, label = { Text("Share a status for 24 hours") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
            Button(onClick = { g.postStatus(draft); draft = "" }, enabled = draft.isNotBlank(), modifier = Modifier.padding(top = 8.dp)) { Text("Post") }
            Text("Goes to your first 30 friends, each as its own private message. Only they can read it.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
            HorizontalDivider()
            LazyColumn {
                items(statuses, key = { it.id }) { s ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                        Text(if (s.authorId.isEmpty()) "You" else s.authorName, fontWeight = FontWeight.SemiBold, color = Brand.primary)
                        Text(s.text)
                        Text(fmtDay(s.timestamp), style = MaterialTheme.typography.labelSmall)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

// ======================================================================== starred

@Composable
fun StarredScreen(g: Graph, onBack: () -> Unit) {
    val starred by remember { g.dao.starred() }.collectAsState(initial = emptyList())
    Scaffold(topBar = { BrandTopBar({ Text("Starred messages") }, onBack) }) { pad ->
        if (starred.isEmpty()) Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("No starred messages.\nLong-press a message to star it.") }
        else LazyColumn(Modifier.padding(pad)) {
            items(starred, key = { it.id }) { m ->
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(if (m.outgoing) "You" else m.senderName.ifBlank { "Them" }, fontWeight = FontWeight.SemiBold, color = Brand.primary)
                    Text(if (m.kind == com.example.meshchat.data.Kind.FILE) "📎 ${m.fileName}" else m.text)
                    Text(fmtDay(m.timestamp), style = MaterialTheme.typography.labelSmall)
                }
                HorizontalDivider()
            }
        }
    }
}

// ======================================================================== settings

@Composable
fun SettingsScreen(g: Graph, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var readReceipts by remember { mutableStateOf(g.readReceipts) }
    var lowPower by remember { mutableStateOf(g.prefs.getBoolean("low_power", false)) }
    val contacts by remember { g.dao.contacts() }.collectAsState(initial = emptyList())
    val blocked = contacts.filter { it.blocked }

    var askBackupPass by remember { mutableStateOf(false) }
    var backupPass by remember { mutableStateOf("") }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            val data = g.exportBackup(backupPass)
            val ok = data != null && runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(data) } }.isSuccess
            Toast.makeText(ctx, if (ok) "Backup saved. Keep the passphrase safe." else "Could not save the backup", Toast.LENGTH_LONG).show()
            backupPass = ""
        }
    }
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { restoreUri = it }

    Scaffold(topBar = { BrandTopBar({ Text("Settings") }, onBack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
            SettingRow("Read receipts (blue ticks)", "If off, you also cannot see when others read your messages.", readReceipts) { readReceipts = it; g.setReadReceipts(it) }
            SettingRow("Battery saver", "Look for nearby phones far less often. Messages arrive later but the battery lasts longer.", lowPower) { lowPower = it; g.setLowPower(it) }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Backup", fontWeight = FontWeight.SemiBold)
            Text("Your ID lives only on this phone. Save an encrypted backup so you can restore it on a new phone. Chat history is not included.", style = MaterialTheme.typography.bodySmall)
            Row {
                OutlinedButton(onClick = { askBackupPass = true }) { Text("Back up my ID") }
                Spacer(Modifier.size(8.dp))
                OutlinedButton(onClick = { openDoc.launch(arrayOf("*/*")) }) { Text("Restore") }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("Blocked contacts", fontWeight = FontWeight.SemiBold)
            if (blocked.isEmpty()) Text("None", style = MaterialTheme.typography.bodySmall)
            blocked.forEach { c ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.name, Modifier.weight(1f))
                    TextButton(onClick = { g.updateContact(c.userId) { it.copy(blocked = false) } }) { Text("Unblock") }
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("About limits", fontWeight = FontWeight.SemiBold)
            Text(
                "Messages travel by Bluetooth, phone to phone, and can hop through other MeshChat phones that cannot read them. " +
                    "Photos, files and calls need a direct Wi-Fi link, so both phones must be close. Wi-Fi Direct needs Android 10+.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
    if (askBackupPass) PassphraseDialog("Back up my ID", "This passphrase encrypts the file. If you forget it, the backup cannot be opened.", onDismiss = { askBackupPass = false }, onConfirm = {
        backupPass = it; askBackupPass = false; createDoc.launch("meshchat-backup.mcb")
    })
    restoreUri?.let { uri ->
        PassphraseDialog("Restore backup", "This replaces the ID on this phone with the one in the backup.", onDismiss = { restoreUri = null }, onConfirm = { pass ->
            restoreUri = null
            scope.launch {
                val data = runCatching { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }.getOrNull()
                val ok = data != null && g.importBackup(data, pass)
                Toast.makeText(ctx, if (ok) "ID restored" else "Wrong passphrase or not a MeshChat backup", Toast.LENGTH_LONG).show()
            }
        })
    }
}

@Composable
private fun SettingRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = value, onCheckedChange = onChange)
    }
}

// ======================================================================== call screen (full-screen overlay)

@Composable
fun CallOverlay(g: Graph) {
    val state by g.calls.state.collectAsState()
    if (state is CallState.Idle) return
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    val peer = when (val s = state) {
        is CallState.Outgoing -> s.peer; is CallState.Incoming -> s.peer; is CallState.Active -> s.peer; else -> return
    }
    val elapsed by produceState(0L, state) {
        val s = state
        while (s is CallState.Active) { value = (System.currentTimeMillis() - s.sinceMs) / 1000; delay(1000) }
    }
    Surface(Modifier.fillMaxSize(), color = Color(0xFF102A27)) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 64.dp)) {
                Avatar(peer.name, 96)
                Spacer(Modifier.size(16.dp))
                Text(peer.name, color = Color.White, style = MaterialTheme.typography.headlineMedium)
                Text(
                    when (state) {
                        is CallState.Outgoing -> "Calling… (connecting over Wi-Fi)"
                        is CallState.Incoming -> "Incoming MeshChat voice call"
                        else -> "%d:%02d".format(elapsed / 60, elapsed % 60)
                    },
                    color = Color.White.copy(alpha = 0.8f),
                )
            }
            when (state) {
                is CallState.Incoming -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Button(onClick = { g.calls.decline() }, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("Decline") }
                    Button(onClick = { g.calls.accept() }, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))) { Text("Answer") }
                }
                else -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { muted = !muted; g.calls.muted = muted }) { Text(if (muted) "Unmute" else "Mute", color = Color.White) }
                    OutlinedButton(onClick = { speaker = !speaker; g.calls.speaker = speaker }) { Text(if (speaker) "Earpiece" else "Speaker", color = Color.White) }
                    Button(onClick = { g.calls.hangup() }, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("End") }
                }
            }
        }
    }
}


// ======================================================================== main navigation destinations

@Composable
fun NearbyScreen(g: Graph, onMyCard: () -> Unit) {
    val nearby by g.nearby.collectAsState()
    val contacts by remember { g.dao.contacts() }.collectAsState(initial = emptyList())
    val trustedCount = contacts.count { it.accepted && !it.blocked && !it.viaGroup }

    Scaffold(topBar = { BrandTopBar({ Text("Nearby") }) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Surface(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(24.dp)) {
                    Text("Live mesh connections", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("$nearby", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(if (nearby == 1) "device connected directly" else "devices connected directly", color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Surface(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.padding(18.dp)) {
                    Text("Privacy by design", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.size(6.dp))
                    Text("Nearby phones are counted as mesh connections. Their names are not exposed here. Exchange QR codes with someone to add them as a trusted contact.")
                }
            }
            Text("Trusted contacts: $trustedCount", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Button(onClick = onMyCard, modifier = Modifier.fillMaxWidth()) { Text("Show my QR / scan a friend") }
        }
    }
}

@Composable
fun GroupsScreen(g: Graph, nav: Nav) {
    val groups by remember { g.dao.groups() }.collectAsState(initial = emptyList())
    Scaffold(
        topBar = { BrandTopBar({ Text("Groups") }) },
        floatingActionButton = { Button(onClick = nav.newGroup) { Text("＋  New group") } },
    ) { pad ->
        if (groups.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No groups yet", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.size(8.dp))
                    Text("Create a private group with people you have added.")
                    Spacer(Modifier.size(16.dp))
                    Button(onClick = nav.newGroup) { Text("Create a group") }
                }
            }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(groups, key = { it.groupId }) { group ->
                    val memberCount = remember(group.info) { GroupInfoPayload.decode(group.info)?.members?.size ?: 0 }
                    Row(
                        Modifier.fillMaxWidth().clickable { nav.open(GROUP_PREFIX + group.groupId) }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(group.name)
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(group.name, fontWeight = FontWeight.SemiBold)
                            Text("$memberCount members · Open group chat", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("›", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}
