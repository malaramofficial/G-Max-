package com.example.meshchat.core

class StoredPacket(val id: ByteArray, val bytes: ByteArray, val fwdTtl: Int, val storedAt: Long)

/**
 * Where the router keeps packets it is carrying (its own unsent ones and other people's, blindly).
 * Android backs this with Room so carried packets survive the app being killed.
 * Called only from the router's single thread.
 */
interface PacketStore {
    fun put(p: StoredPacket)
    fun get(idHex: String): StoredPacket?
    /** Newest last. */
    fun recent(n: Int): List<StoredPacket>
    fun count(): Int
    fun purgeOlderThan(cutoffMs: Long)
    fun trimTo(max: Int)
}

class InMemoryPacketStore : PacketStore {
    private val map = LinkedHashMap<String, StoredPacket>()
    @Synchronized override fun put(p: StoredPacket) { map.remove(p.id.toHex()); map[p.id.toHex()] = p }
    @Synchronized override fun get(idHex: String) = map[idHex]
    @Synchronized override fun recent(n: Int) = map.values.toList().takeLast(n)
    @Synchronized override fun count() = map.size
    @Synchronized override fun purgeOlderThan(cutoffMs: Long) { map.values.removeAll { it.storedAt < cutoffMs } }
    @Synchronized override fun trimTo(max: Int) {
        while (map.size > max) { val it = map.keys.iterator(); it.next(); it.remove() }
    }
}
