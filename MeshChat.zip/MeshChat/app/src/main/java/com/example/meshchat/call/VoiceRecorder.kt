package com.example.meshchat.call

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaRecorder
import java.io.File

/** Records a voice note (AAC in .m4a). It is then sent like any other file. */
class VoiceRecorder(private val ctx: Context) {
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start(): Boolean = try {
        val f = File(ctx.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        val r = MediaRecorder()
        r.setAudioSource(MediaRecorder.AudioSource.MIC)
        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        r.setAudioSamplingRate(16_000)
        r.setAudioEncodingBitRate(24_000) // small files: a 1-minute note is ~180 KB
        r.setOutputFile(f.absolutePath)
        r.prepare(); r.start()
        recorder = r; file = f; startedAt = System.currentTimeMillis()
        true
    } catch (e: Exception) {
        recorder = null; false
    }

    /** Returns the recorded file, or null if it was too short or failed. */
    fun stop(): File? {
        val r = recorder ?: return null
        recorder = null
        val tooShort = System.currentTimeMillis() - startedAt < 700
        val ok = runCatching { r.stop() }.isSuccess
        runCatching { r.release() }
        val f = file
        if (!ok || tooShort) { f?.delete(); return null }
        return f
    }
}
