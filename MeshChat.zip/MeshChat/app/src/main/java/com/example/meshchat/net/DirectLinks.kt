package com.example.meshchat.net

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.MacAddress
import android.net.NetworkCapabilities
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address
import java.security.SecureRandom

/**
 * Fast phone-to-phone Wi-Fi for files and calls (BLE is too slow for those). Two ways, chosen automatically:
 *  - [lanIpv4]: both phones are already on the same Wi-Fi / hotspot -> use that, nothing to set up.
 *  - Wi-Fi Direct: no router needed. The sender [host]s a temporary group, puts its name+password inside the
 *    encrypted message, and the receiver [join]s it. Needs Android 10+. While joined, the receiver's normal
 *    Wi-Fi connection may drop for a moment.
 *
 * NOT yet compiled or run on a device: Wi-Fi Direct behaves differently across phone makers, test on real phones.
 */
@SuppressLint("MissingPermission")
class DirectLinks(private val ctx: Context) {
    private val manager = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private val channel = manager?.initialize(ctx, Looper.getMainLooper(), null)
    private val main = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()
    private var hosted: Pair<String, String>? = null
    private var hostedAt = 0L

    val wifiDirectSupported: Boolean get() = manager != null && channel != null && Build.VERSION.SDK_INT >= 29

    /** This phone's IPv4 on a Wi-Fi network, or null if it is not connected to one. */
    @Suppress("DEPRECATION")
    fun lanIpv4(): ByteArray? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
        for (net in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(net) ?: continue
            if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue
            val addr = cm.getLinkProperties(net)?.linkAddresses
                ?.map { it.address }?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            if (addr != null) return addr.address
        }
        return null
    }

    /** Starts (or reuses) a Wi-Fi Direct group. Calls back with (name, password) or null. */
    fun host(cb: (Pair<String, String>?) -> Unit) {
        val m = manager; val ch = channel
        if (!wifiDirectSupported || m == null || ch == null) { cb(null); return }
        hosted?.let { if (System.currentTimeMillis() - hostedAt < 14 * 60_000) { cb(it); return } }
        val ssid = "DIRECT-mc-" + randomAlnum(4)
        val pass = randomAlnum(10)
        val create = {
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).enablePersistentMode(false).build()
            m.createGroup(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { hosted = ssid to pass; hostedAt = System.currentTimeMillis(); cb(ssid to pass) }
                override fun onFailure(reason: Int) { cb(null) }
            })
        }
        // A group may already exist (BUSY), so remove it first and ignore the result.
        m.removeGroup(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { create() }
            override fun onFailure(reason: Int) { create() }
        })
    }

    /** Joins a group made by [host] and calls back with the group owner's IP address, or null on failure/timeout. */
    fun join(ssid: String, pass: String, timeoutMs: Long = 25_000, cb: (String?) -> Unit) {
        val m = manager; val ch = channel
        if (!wifiDirectSupported || m == null || ch == null) { cb(null); return }
        var done = false
        lateinit var receiver: BroadcastReceiver
        val finish = { result: String? ->
            if (!done) { done = true; runCatching { ctx.unregisterReceiver(receiver) }; cb(result) }
        }
        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                m.requestConnectionInfo(ch) { info ->
                    if (info != null && info.groupFormed && !info.isGroupOwner) finish(info.groupOwnerAddress?.hostAddress)
                }
            }
        }
        ctx.registerReceiver(receiver, IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION))
        main.postDelayed({ finish(null) }, timeoutMs)
        val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass)
            .setDeviceAddress(MacAddress.fromString("02:00:00:00:00:00")).build()
        m.connect(ch, cfg, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {}
            override fun onFailure(reason: Int) { finish(null) }
        })
    }

    /** Tear down whatever group we are in or hosting (frees the radio, saves battery). */
    fun leave() {
        hosted = null
        val m = manager; val ch = channel
        if (m != null && ch != null) runCatching { m.removeGroup(ch, null) }
    }

    private fun randomAlnum(n: Int): String {
        val chars = "abcdefghijkmnpqrstuvwxyz23456789"
        return String(CharArray(n) { chars[rng.nextInt(chars.length)] })
    }
}
