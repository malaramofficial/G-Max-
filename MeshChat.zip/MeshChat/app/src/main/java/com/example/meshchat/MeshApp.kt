package com.example.meshchat

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.room.Room
import com.example.meshchat.ble.BleTransport
import com.example.meshchat.call.CallManager
import com.example.meshchat.core.Backup
import com.example.meshchat.core.BackupContent
import com.example.meshchat.core.CallAcceptPayload
import com.example.meshchat.core.CallEndPayload
import com.example.meshchat.core.CallInvitePayload
import com.example.meshchat.core.Contact
import com.example.meshchat.core.ContactCard
import com.example.meshchat.core.ContactDirectory
import com.example.meshchat.core.DeletePayload
import com.example.meshchat.core.Endpoint
import com.example.meshchat.core.FileClient
import com.example.meshchat.core.FileCrypto
import com.example.meshchat.core.FileOfferPayload
import com.example.meshchat.core.FileServer
import com.example.meshchat.core.Group
import com.example.meshchat.core.GroupInfoPayload
import com.example.meshchat.core.GroupTextPayload
import com.example.meshchat.core.Groups
import com.example.meshchat.core.Identity
import com.example.meshchat.core.MeshEvents
import com.example.meshchat.core.MeshRouter
import com.example.meshchat.core.ReadPayload
import com.example.meshchat.core.Scheduler
import com.example.meshchat.core.SealedPacketCodec
import com.example.meshchat.core.StatusPayload
import com.example.meshchat.core.TextPayload
import com.example.meshchat.core.Wire
import com.example.meshchat.core.hexToBytes
import com.example.meshchat.core.toHex
import com.example.meshchat.crypto.TinkCurve25519Provider
import com.example.meshchat.data.AppDb
import com.example.meshchat.data.ContactEntity
import com.example.meshchat.data.FileState
import com.example.meshchat.data.GROUP_PREFIX
import com.example.meshchat.data.GroupEntity
import com.example.meshchat.data.KeyVault
import com.example.meshchat.data.Kind
import com.example.meshchat.data.MessageEntity
import com.example.meshchat.data.RoomPacketStore
import com.example.meshchat.data.StatusEntity
import com.example.meshchat.net.DirectLinks
import com.example.meshchat.service.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.security.SecureRandom
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class MeshApp : Application() {
    lateinit var graph: Graph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
    }
}

/**
 * Wires identity, database, mesh router, BLE, Wi-Fi links, files, groups, status and calls together.
 * All router work runs on one thread (meshThread); database work runs on [scope].
 */
class Graph(private val app: Application) : ContactDirectory, MeshEvents {
    val provider = TinkCurve25519Provider()
    private val vault = KeyVault(app)
    private val db = Room.databaseBuilder(app, AppDb::class.java, "meshchat.db").build()
    val dao = db.dao()
    private val packetStore = RoomPacketStore(db.packetDao())
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val meshThread = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()

    val transport = BleTransport(app)
    val directLinks = DirectLinks(app)
    private val fileServer = FileServer()
    val nearby = MutableStateFlow(0)
    /** One-line messages for the UI to show as toasts. */
    val toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    /** The chat currently on screen: no notification is raised for it. */
    @Volatile var openChatId: String? = null

    val calls = CallManager(
        ctx = app, links = directLinks,
        sendSealed = { c, type, payload -> meshThread.execute { runCatching { router()?.send(c, type, payload) } } },
        onCallLogged = { peer, outgoing, dur, answered -> logCall(peer, outgoing, dur, answered) },
        onRinging = { Notifier.incomingCall(app, it.name) },
    )

    @Volatile var identity: Identity? = vault.load()
        private set
    @Volatile private var contactsCache: List<ContactEntity> = emptyList()
    @Volatile private var accepted: List<Contact> = emptyList()
    @Volatile private var routerRef: MeshRouter? = null

    init {
        Notifier.init(app)
        transport.lowPower = prefs.getBoolean("low_power", false)
        scope.launch {
            dao.contacts().collect { list ->
                contactsCache = list
                accepted = list.filter { it.accepted && !it.blocked }.map { Contact(it.edPublic, it.xPublic, it.name) }
            }
        }
        transport.onFrame = { peer, frame -> meshThread.execute { routerRef?.onFrame(peer, frame) } }
        transport.onPeerUp = { peer ->
            nearby.value = transport.peers().size
            meshThread.execute { routerRef?.onPeerConnected(peer) }
        }
        transport.onPeerDown = { nearby.value = transport.peers().size }
    }

    // ---------------- identity / lifecycle ----------------

    fun createIdentity(name: String): Identity {
        val id = Identity.generate(provider, name.ifBlank { "Me" })
        vault.save(id)
        identity = id
        return id
    }

    @Synchronized
    private fun router(): MeshRouter? {
        routerRef?.let { return it }
        val me = identity ?: return null
        val scheduler = object : Scheduler {
            override fun postDelayed(delayMs: Long, task: () -> Unit) {
                mainHandler.postDelayed({ meshThread.execute(task) }, delayMs)
            }
        }
        return MeshRouter(
            me = me, codec = SealedPacketCodec(provider), contacts = this, transport = transport,
            scheduler = scheduler, events = this, nowMs = System::currentTimeMillis, store = packetStore,
        ).also { routerRef = it }
    }

    fun startMesh() {
        router()
        transport.start()
        runCatching { fileServer.start() }
        scope.launch { dao.deleteStatusesBefore(System.currentTimeMillis() - DAY_MS) }
    }

    fun stopMesh() { transport.stop(); fileServer.stop() }

    fun setLowPower(on: Boolean) { prefs.edit().putBoolean("low_power", on).apply(); transport.lowPower = on }
    fun setReadReceipts(on: Boolean) = prefs.edit().putBoolean("read_receipts", on).apply()
    val readReceipts: Boolean get() = prefs.getBoolean("read_receipts", true)

    // ---------------- contacts & groups ----------------

    /** Scanning a card in person is what makes someone a trusted contact. Returns the text to show the user. */
    suspend fun addContactFromLink(link: String): String {
        val card = ContactCard.fromLink(link.trim()) ?: return "This is not a MeshChat QR"
        if (!card.verify(provider)) return "This QR is damaged or edited"
        if (card.userId == identity?.userId) return "That is your own ID"
        val old = dao.contact(card.userId)
        dao.upsertContact(
            (old ?: ContactEntity(card.userId, card.name, card.edPublic, card.xPublic))
                .copy(name = card.name, accepted = true, blocked = false, viaGroup = false)
        )
        return "Added ${card.name} (${card.userId})"
    }

    fun updateContact(userId: String, change: (ContactEntity) -> ContactEntity) {
        scope.launch { dao.contact(userId)?.let { dao.upsertContact(change(it)) } }
    }

    fun updateGroup(groupId: String, change: (GroupEntity) -> GroupEntity) {
        scope.launch { dao.group(groupId.removePrefix(GROUP_PREFIX))?.let { dao.upsertGroup(change(it)) } }
    }

    /** Group of 2-8 people including you. Every member must be one of your contacts. */
    fun createGroup(name: String, memberUserIds: List<String>): Boolean {
        val me = identity ?: return false
        val others = memberUserIds.mapNotNull { id -> contactsCache.firstOrNull { it.userId == id } }
            .map { Contact(it.edPublic, it.xPublic, it.name) }
        val members = others + Contact(me.edPublic, me.xPublic, me.name)
        if (name.isBlank() || members.size !in 3..GroupInfoPayload.MAX_MEMBERS) return false
        val gid = Groups.newId()
        val info = GroupInfoPayload(gid, name.trim().take(40), members)
        scope.launch {
            dao.upsertGroup(GroupEntity(gid.toHex(), info.name, info.encode()))
            systemMessage(GROUP_PREFIX + gid.toHex(), "You created the group “${info.name}”")
            meshThread.execute { router()?.let { Groups.sendInfo(it, me, Group(gid, info.name, members)) } }
        }
        return true
    }

    private suspend fun loadGroup(chatId: String): Group? {
        val e = dao.group(chatId.removePrefix(GROUP_PREFIX)) ?: return null
        val info = GroupInfoPayload.decode(e.info) ?: return null
        return Group(info.groupId, info.name, info.members)
    }

    // ---------------- sending ----------------

    private fun newId(): ByteArray = ByteArray(16).also { rng.nextBytes(it) }

    /** Seals and sends one message to a person, or fans it out to every other member of a group. */
    private suspend fun dispatch(chatId: String, type: Int, payload: ByteArray, msgId: ByteArray) {
        val me = identity ?: return
        if (chatId.startsWith(GROUP_PREFIX)) {
            val group = loadGroup(chatId) ?: return
            meshThread.execute { router()?.let { runCatching { Groups.sendRaw(it, me, group, type, payload, msgId) } } }
        } else {
            val c = dao.contact(chatId) ?: return
            val contact = Contact(c.edPublic, c.xPublic, c.name)
            meshThread.execute { runCatching { router()?.send(contact, type, payload, msgId) } }
        }
    }

    fun maxTextBytes(chatId: String, withReply: Boolean) =
        TextPayload.maxTextBytes(withReply, if (chatId.startsWith(GROUP_PREFIX)) 16 else 0)

    fun sendText(chatId: String, text: String, replyTo: String? = null) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val isGroup = chatId.startsWith(GROUP_PREFIX)
        val inner = TextPayload(clean, replyTo?.hexToBytes())
        val payload = if (isGroup) GroupTextPayload(chatId.removePrefix(GROUP_PREFIX).hexToBytes(), inner).encode() else inner.encode()
        if (payload.size > Wire.MAX_PAYLOAD) return
        val msgId = newId()
        scope.launch {
            dao.insertMessage(
                MessageEntity(msgId = msgId.toHex(), chatId = chatId, outgoing = true, text = clean, replyTo = replyTo, timestamp = System.currentTimeMillis())
            )
            dispatch(chatId, if (isGroup) Wire.TYPE_GROUP_TEXT else Wire.TYPE_TEXT, payload, msgId)
        }
    }

    fun forward(text: String, toChatId: String) = sendText(toChatId, text)

    /** Photo / video / document / voice note. Only a small encrypted offer goes through the mesh; bytes go over Wi-Fi. */
    fun sendFile(chatId: String, uri: Uri?, localFile: File?, name: String, mime: String) {
        scope.launch {
            val fileId = FileCrypto.newId()
            val key = FileCrypto.newKey()
            val dest = File(app.filesDir, "out/${fileId.toHex()}").also { it.parentFile!!.mkdirs() }
            try {
                if (uri != null) app.contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { i.copyTo(it) } }
                else { localFile!!.copyTo(dest, overwrite = true); localFile.delete() }
            } catch (e: Exception) { toasts.tryEmit("Could not read that file"); return@launch }

            fileServer.register(fileId, key, dest)
            val port = runCatching { fileServer.start() }.getOrDefault(0)
            val lan = directLinks.lanIpv4()
            val endpoint = if (lan != null) Endpoint(lan, port) else {
                val creds = hostBlocking()
                if (creds == null) toasts.tryEmit("Wi-Fi Direct is not available: connect both phones to the same Wi-Fi to share files")
                Endpoint(null, port, creds?.first ?: "", creds?.second ?: "")
            }
            val offer = FileOfferPayload(fileId, key, dest.length(), FileCrypto.sha256(dest), name, mime, endpoint)
            val msgId = newId()
            dao.insertMessage(
                MessageEntity(
                    msgId = msgId.toHex(), chatId = chatId, outgoing = true, kind = Kind.FILE, timestamp = System.currentTimeMillis(),
                    fileName = name, fileMime = mime, fileSize = dest.length(), filePath = dest.absolutePath, fileState = FileState.DONE,
                )
            )
            dispatch(chatId, Wire.TYPE_FILE_OFFER, offer.encode(), msgId)
        }
    }

    /** Receiver taps "Download": try the same Wi-Fi first, then join the sender's Wi-Fi Direct group. */
    fun downloadFile(rowId: Long) {
        scope.launch {
            val row = dao.messageById(rowId) ?: return@launch
            val offer = row.offer?.let { FileOfferPayload.decode(it) } ?: return@launch
            if (row.fileState == FileState.DOWNLOADING) return@launch
            dao.updateMessage(row.copy(fileState = FileState.DOWNLOADING))
            val dest = File(app.filesDir, "in/${offer.fileId.toHex()}_${offer.name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                .also { it.parentFile!!.mkdirs() }
            var ok = false
            offer.endpoint.lanHost()?.let { ok = FileClient.fetch(it, offer.endpoint.port, offer, dest) }
            if (!ok && offer.endpoint.ssid.isNotBlank()) {
                val go = joinBlocking(offer.endpoint.ssid, offer.endpoint.passphrase)
                if (go != null) ok = FileClient.fetch(go, offer.endpoint.port, offer, dest, connectTimeoutMs = 6000)
                directLinks.leave()
            }
            if (!ok) toasts.tryEmit("Could not download. Be close to the sender (same Wi-Fi, or within Wi-Fi Direct range) and try again")
            dao.updateMessage(row.copy(fileState = if (ok) FileState.DONE else FileState.FAILED, filePath = if (ok) dest.absolutePath else null))
        }
    }

    fun deleteForEveryone(rowId: Long) {
        scope.launch {
            val row = dao.messageById(rowId) ?: return@launch
            if (!row.outgoing || row.deleted || row.kind == Kind.SYSTEM) return@launch
            dispatch(row.chatId, Wire.TYPE_DELETE, DeletePayload(row.msgId.hexToBytes()).encode(), newId())
            wipe(row)
        }
    }

    fun deleteForMe(rowId: Long) = scope.launch { dao.deleteMessage(rowId) }

    fun toggleStar(rowId: Long) = scope.launch { dao.messageById(rowId)?.let { dao.updateMessage(it.copy(starred = !it.starred)) } }

    private suspend fun wipe(row: MessageEntity) {
        row.filePath?.let { File(it).delete() }
        dao.updateMessage(row.copy(deleted = true, text = "", filePath = null, offer = null, fileState = FileState.NONE, starred = false))
    }

    /** Called when a chat is on screen: clears unread and (1-to-1 only, if enabled) sends "seen" ticks. */
    fun markChatRead(chatId: String) {
        scope.launch {
            val ids = dao.unreadIncomingIds(chatId)
            if (ids.isEmpty()) return@launch
            dao.markRead(chatId)
            Notifier.cancel(app, chatId)
            if (!chatId.startsWith(GROUP_PREFIX) && readReceipts) {
                ids.chunked(40).forEach { batch ->
                    dispatch(chatId, Wire.TYPE_READ, ReadPayload(batch.map { it.hexToBytes() }).encode(), newId())
                }
            }
        }
    }

    // ---------------- status (24 h text) ----------------

    /** Sent to each of your (up to 30) contacts as its own sealed packet; disappears after 24 hours. */
    fun postStatus(text: String) {
        val t = text.trim().take(250)
        if (t.isEmpty()) return
        val me = identity ?: return
        scope.launch {
            dao.insertStatus(StatusEntity(authorId = "", authorName = me.name, text = t, timestamp = System.currentTimeMillis()))
            val targets = contactsCache.filter { it.accepted && !it.blocked && !it.viaGroup }.take(30)
                .map { Contact(it.edPublic, it.xPublic, it.name) }
            meshThread.execute { router()?.let { r -> targets.forEach { runCatching { r.send(it, Wire.TYPE_STATUS, StatusPayload(t).encode()) } } } }
        }
    }

    fun startCall(userId: String) {
        scope.launch {
            val c = dao.contact(userId) ?: return@launch
            calls.startCall(Contact(c.edPublic, c.xPublic, c.name))
        }
    }

    // ---------------- backup ----------------

    suspend fun exportBackup(passphrase: String): ByteArray? {
        val me = identity ?: return null
        val cs = contactsCache.filter { !it.viaGroup }.map { Contact(it.edPublic, it.xPublic, it.name) }
        return Backup.export(BackupContent(me, cs), passphrase)
    }

    suspend fun importBackup(data: ByteArray, passphrase: String): Boolean {
        val c = Backup.import(data, passphrase) ?: return false
        vault.save(c.identity)
        identity = c.identity
        routerRef = null
        c.contacts.forEach { dao.upsertContact(ContactEntity(it.userId, it.name, it.edPublic, it.xPublic)) }
        startMesh()
        return true
    }

    // ---------------- router callbacks ----------------

    override fun findAccepted(edPublic: ByteArray): Contact? =
        accepted.firstOrNull { it.edPublic.contentEquals(edPublic) }

    /** The ONLY place anything reaches the user, and only the real recipient ever gets here. Runs on meshThread: hand off fast. */
    override fun onInbound(from: Contact, type: Int, msgId: ByteArray, timestampMs: Long, payload: ByteArray) {
        when (type) {
            Wire.TYPE_TEXT -> TextPayload.decode(payload)?.let {
                incoming(from, from.userId, msgId, timestampMs, Kind.TEXT, it.text, it.replyTo?.toHex(), null)
            }
            Wire.TYPE_GROUP_TEXT -> GroupTextPayload.decode(payload)?.let { g ->
                incoming(from, GROUP_PREFIX + g.groupId.toHex(), msgId, timestampMs, Kind.TEXT, g.text.text, g.text.replyTo?.toHex(), null)
            }
            Wire.TYPE_FILE_OFFER -> FileOfferPayload.decode(payload)?.let { o ->
                incoming(from, from.userId, msgId, timestampMs, Kind.FILE, "", null, o, payload)
            }
            Wire.TYPE_GROUP_INFO -> GroupInfoPayload.decode(payload)?.let { onGroupInfo(from, it) }
            Wire.TYPE_STATUS -> if (timestampMs > System.currentTimeMillis() - DAY_MS) scope.launch {
                dao.insertStatus(StatusEntity(authorId = from.userId, authorName = from.name, text = StatusPayload.decode(payload).text, timestamp = timestampMs))
            }
            Wire.TYPE_READ -> ReadPayload.decode(payload)?.let { r ->
                scope.launch { dao.markSeen(from.userId, r.ids.map { it.toHex() }) }
            }
            Wire.TYPE_DELETE -> DeletePayload.decode(payload)?.let { d ->
                scope.launch {
                    val row = dao.messageByMsgId(d.msgId.toHex())
                    if (row != null && row.senderId == from.userId) wipe(row) // only the original sender can delete it
                }
            }
            Wire.TYPE_CALL_INVITE -> CallInvitePayload.decode(payload)?.let { calls.onInvite(from, it) }
            Wire.TYPE_CALL_ACCEPT -> CallAcceptPayload.decode(payload)?.let { calls.onAccept(from, it) }
            Wire.TYPE_CALL_END -> CallEndPayload.decode(payload)?.let { Notifier.cancelCall(app); calls.onEnd(from, it) }
        }
    }

    override fun onDelivered(to: Contact, msgId: ByteArray) {
        scope.launch { dao.markDelivered(msgId.toHex()) }
    }

    private fun incoming(
        from: Contact, chatId: String, msgId: ByteArray, ts: Long, kind: Int, text: String,
        replyTo: String?, offer: FileOfferPayload?, offerBytes: ByteArray? = null,
    ) {
        scope.launch {
            val isGroup = chatId.startsWith(GROUP_PREFIX)
            val group = if (isGroup) loadGroup(chatId) else null
            if (isGroup && (group == null || group.members.none { it.edPublic.contentEquals(from.edPublic) })) return@launch // not a member
            val contact = dao.contact(from.userId)
            val row = MessageEntity(
                msgId = msgId.toHex(), chatId = chatId, senderId = from.userId, senderName = from.name, outgoing = false,
                kind = kind, text = text, replyTo = replyTo, timestamp = ts, unread = true,
                fileName = offer?.name, fileMime = offer?.mime, fileSize = offer?.size ?: 0,
                fileState = if (offer != null) FileState.OFFERED else FileState.NONE, offer = offerBytes,
            )
            if (dao.insertMessage(row) == -1L) return@launch // duplicate
            val muted = if (isGroup) dao.group(chatId.removePrefix(GROUP_PREFIX))?.muted == true else contact?.muted == true
            if (!muted && openChatId != chatId) {
                val body = if (kind == Kind.FILE) "📎 ${offer?.name}" else text
                Notifier.message(app, chatId, group?.name ?: from.name, if (isGroup) "${from.name}: $body" else body)
            }
        }
    }

    private fun onGroupInfo(from: Contact, info: GroupInfoPayload) {
        val me = identity ?: return
        if (info.members.none { it.edPublic.contentEquals(from.edPublic) } || info.members.none { it.edPublic.contentEquals(me.edPublic) }) return
        scope.launch {
            val existing = dao.group(info.groupId.toHex())
            if (existing != null) {
                // Only an existing member may change a group (stops outsiders hijacking it).
                val old = GroupInfoPayload.decode(existing.info)
                if (old == null || old.members.none { it.edPublic.contentEquals(from.edPublic) }) return@launch
            }
            // Members you have not scanned yet become hidden contacts, so their group messages can reach you.
            info.members.filter { !it.edPublic.contentEquals(me.edPublic) }.forEach {
                dao.insertContactIfAbsent(ContactEntity(it.userId, it.name, it.edPublic, it.xPublic, viaGroup = true))
            }
            dao.upsertGroup((existing ?: GroupEntity(info.groupId.toHex(), info.name, info.encode())).copy(name = info.name, info = info.encode()))
            if (existing == null) {
                systemMessage(GROUP_PREFIX + info.groupId.toHex(), "${from.name} added you to “${info.name}”")
                Notifier.message(app, GROUP_PREFIX + info.groupId.toHex(), info.name, "${from.name} added you to the group")
            }
        }
    }

    private fun logCall(peer: Contact, outgoing: Boolean, durMs: Long, answered: Boolean) {
        val text = when {
            answered -> "📞 Voice call · %d:%02d".format(durMs / 60000, durMs / 1000 % 60)
            outgoing -> "📞 Call not answered"
            else -> "📞 Missed voice call"
        }
        Notifier.cancelCall(app)
        scope.launch {
            dao.insertMessage(
                MessageEntity(
                    msgId = newId().toHex(), chatId = peer.userId, senderId = if (outgoing) "" else peer.userId, outgoing = outgoing,
                    kind = Kind.SYSTEM, text = text, timestamp = System.currentTimeMillis(), unread = !outgoing && !answered,
                )
            )
            if (!outgoing && !answered) Notifier.message(app, peer.userId, peer.name, text)
        }
    }

    private suspend fun systemMessage(chatId: String, text: String) {
        dao.insertMessage(MessageEntity(msgId = newId().toHex(), chatId = chatId, outgoing = false, kind = Kind.SYSTEM, text = text, timestamp = System.currentTimeMillis()))
    }

    // ---------------- Wi-Fi Direct helpers (callback -> suspend) ----------------

    private suspend fun hostBlocking(): Pair<String, String>? =
        suspendCoroutine { cont -> mainHandler.post { directLinks.host { cont.resume(it) } } }

    private suspend fun joinBlocking(ssid: String, pass: String): String? =
        suspendCoroutine { cont -> mainHandler.post { directLinks.join(ssid, pass) { cont.resume(it) } } }

    private companion object { const val DAY_MS = 24L * 60 * 60 * 1000 }
}
