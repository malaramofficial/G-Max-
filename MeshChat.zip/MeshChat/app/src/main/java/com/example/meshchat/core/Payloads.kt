package com.example.meshchat.core

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

internal class W {
    private val o = ByteArrayOutputStream()
    fun u8(v: Int): W { o.write(v); return this }
    fun u16(v: Int): W { o.write(v shr 8); o.write(v); return this }
    fun u64(v: Long): W { for (i in 7 downTo 0) o.write((v shr (8 * i)).toInt()); return this }
    fun raw(b: ByteArray): W { o.write(b); return this }
    fun str(s: String, maxBytes: Int): W {
        val b = limitUtf8(s, maxBytes).toByteArray(Charsets.UTF_8)
        u16(b.size); raw(b); return this
    }
    fun bytes(): ByteArray = o.toByteArray()
}

internal class R(data: ByteArray) {
    private val b = ByteBuffer.wrap(data)
    fun u8(): Int = b.get().toInt() and 0xFF
    fun u16(): Int = b.getShort().toInt() and 0xFFFF
    fun u64(): Long = b.getLong()
    fun raw(n: Int): ByteArray {
        require(n in 0..b.remaining())
        return ByteArray(n).also { b.get(it) }
    }
    fun str(): String = String(raw(u16()), Charsets.UTF_8)
    fun rest(): ByteArray = raw(b.remaining())
}

/** Where a peer can fetch a file / send call audio: a LAN IPv4 and/or a Wi-Fi Direct group to join. */
class Endpoint(val lanIp: ByteArray?, val port: Int, val ssid: String = "", val passphrase: String = "") {
    fun lanHost(): String? = lanIp?.joinToString(".") { (it.toInt() and 0xFF).toString() }
    internal fun writeTo(w: W) {
        if (lanIp != null) { w.u8(4); w.raw(lanIp) } else w.u8(0)
        w.u16(port); w.str(ssid, 40); w.str(passphrase, 40)
    }
    companion object {
        internal fun readFrom(r: R): Endpoint {
            val n = r.u8()
            require(n == 0 || n == 4)
            val ip = if (n == 4) r.raw(4) else null
            return Endpoint(ip, r.u16(), r.str(), r.str())
        }
    }
}

class TextPayload(val text: String, val replyTo: ByteArray? = null) {
    fun encode(): ByteArray {
        val w = W()
        if (replyTo != null) { w.u8(1); w.raw(replyTo) } else w.u8(0)
        return w.raw(text.toByteArray(Charsets.UTF_8)).bytes()
    }
    companion object {
        /** How many UTF-8 bytes of text fit in one packet. */
        fun maxTextBytes(withReply: Boolean, extra: Int = 0) = Wire.MAX_PAYLOAD - 1 - (if (withReply) 16 else 0) - extra
        fun decode(b: ByteArray): TextPayload? = try {
            val r = R(b)
            val reply = if (r.u8() == 1) r.raw(16) else null
            TextPayload(String(r.rest(), Charsets.UTF_8), reply)
        } catch (e: RuntimeException) { null }
    }
}

class GroupTextPayload(val groupId: ByteArray, val text: TextPayload) {
    fun encode(): ByteArray = groupId + text.encode()
    companion object {
        fun decode(b: ByteArray): GroupTextPayload? {
            if (b.size < 17) return null
            val t = TextPayload.decode(b.copyOfRange(16, b.size)) ?: return null
            return GroupTextPayload(b.copyOfRange(0, 16), t)
        }
    }
}

/** Members include the creator and the receiver. Max 8 so it fits in one packet. */
class GroupInfoPayload(val groupId: ByteArray, val name: String, val members: List<Contact>) {
    fun encode(): ByteArray {
        require(members.size in 2..MAX_MEMBERS)
        val w = W().raw(groupId).str(name, 40).u8(members.size)
        for (m in members) { w.raw(m.edPublic); w.raw(m.xPublic); w.str(m.name, 40) }
        return w.bytes()
    }
    companion object {
        const val MAX_MEMBERS = 8
        fun decode(b: ByteArray): GroupInfoPayload? = try {
            val r = R(b)
            val id = r.raw(16); val name = r.str(); val n = r.u8()
            require(n in 2..MAX_MEMBERS)
            GroupInfoPayload(id, name, List(n) { Contact(r.raw(32), r.raw(32), r.str()) })
        } catch (e: RuntimeException) { null }
    }
}

class ReadPayload(val ids: List<ByteArray>) {
    fun encode(): ByteArray {
        val w = W().u8(ids.size.coerceAtMost(40))
        ids.take(40).forEach { w.raw(it) }
        return w.bytes()
    }
    companion object {
        fun decode(b: ByteArray): ReadPayload? = try {
            val r = R(b); val n = r.u8()
            ReadPayload(List(n) { r.raw(16) })
        } catch (e: RuntimeException) { null }
    }
}

class DeletePayload(val msgId: ByteArray) {
    fun encode(): ByteArray = msgId
    companion object { fun decode(b: ByteArray): DeletePayload? = if (b.size == 16) DeletePayload(b) else null }
}

/** A 24-hour text status; expiry = message timestamp + 24h. */
class StatusPayload(val text: String) {
    fun encode(): ByteArray = text.toByteArray(Charsets.UTF_8)
    companion object { fun decode(b: ByteArray) = StatusPayload(String(b, Charsets.UTF_8)) }
}

class FileOfferPayload(
    val fileId: ByteArray,
    val key: ByteArray,
    val size: Long,
    val sha256: ByteArray,
    val name: String,
    val mime: String,
    val endpoint: Endpoint,
) {
    fun encode(): ByteArray {
        val w = W().raw(fileId).raw(key).u64(size).raw(sha256).str(name, 100).str(mime, 40)
        endpoint.writeTo(w)
        return w.bytes()
    }
    companion object {
        fun decode(b: ByteArray): FileOfferPayload? = try {
            val r = R(b)
            FileOfferPayload(r.raw(16), r.raw(32), r.u64(), r.raw(32), r.str(), r.str(), Endpoint.readFrom(r))
        } catch (e: RuntimeException) { null }
    }
}

class CallInvitePayload(val callId: ByteArray, val key: ByteArray, val endpoint: Endpoint) {
    fun encode(): ByteArray {
        val w = W().raw(callId).raw(key)
        endpoint.writeTo(w)
        return w.bytes()
    }
    companion object {
        fun decode(b: ByteArray): CallInvitePayload? = try {
            val r = R(b)
            CallInvitePayload(r.raw(16), r.raw(32), Endpoint.readFrom(r))
        } catch (e: RuntimeException) { null }
    }
}

class CallAcceptPayload(val callId: ByteArray) {
    fun encode(): ByteArray = callId
    companion object { fun decode(b: ByteArray): CallAcceptPayload? = if (b.size == 16) CallAcceptPayload(b) else null }
}

class CallEndPayload(val callId: ByteArray, val reason: Int) {
    fun encode(): ByteArray = callId + byteArrayOf(reason.toByte())
    companion object {
        const val HANGUP = 0
        const val DECLINED = 1
        const val BUSY = 2
        fun decode(b: ByteArray): CallEndPayload? =
            if (b.size == 17) CallEndPayload(b.copyOfRange(0, 16), b[16].toInt() and 0xFF) else null
    }
}
