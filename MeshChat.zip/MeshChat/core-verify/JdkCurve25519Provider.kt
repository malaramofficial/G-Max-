package verify

import com.example.meshchat.core.Curve25519Provider
import com.example.meshchat.core.RawKeyPair
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement

/** Test-only provider using the JDK's built-in X25519/Ed25519 (the app uses Tink instead). */
class JdkCurve25519Provider : Curve25519Provider {
    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    private val xPubPrefix = hex("302a300506032b656e032100")
    private val xPrivPrefix = hex("302e020100300506032b656e04220420")
    private val edPubPrefix = hex("302a300506032b6570032100")
    private val edPrivPrefix = hex("302e020100300506032b657004220420")

    private fun gen(alg: String): RawKeyPair {
        val kp = KeyPairGenerator.getInstance(alg).generateKeyPair()
        return RawKeyPair(kp.public.encoded.takeLast(32).toByteArray(), kp.private.encoded.takeLast(32).toByteArray())
    }

    override fun newX25519() = gen("X25519")
    override fun newEd25519() = gen("Ed25519")

    override fun x25519(privateKey: ByteArray, peerPublic: ByteArray): ByteArray {
        val kf = KeyFactory.getInstance("X25519")
        val priv = kf.generatePrivate(PKCS8EncodedKeySpec(xPrivPrefix + privateKey))
        val pub = kf.generatePublic(X509EncodedKeySpec(xPubPrefix + peerPublic))
        val ka = KeyAgreement.getInstance("X25519")
        ka.init(priv)
        ka.doPhase(pub, true)
        return ka.generateSecret()
    }

    override fun sign(privateSeed: ByteArray, message: ByteArray): ByteArray {
        val priv = KeyFactory.getInstance("Ed25519").generatePrivate(PKCS8EncodedKeySpec(edPrivPrefix + privateSeed))
        val s = Signature.getInstance("Ed25519")
        s.initSign(priv); s.update(message)
        return s.sign()
    }

    override fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean = try {
        val pub = KeyFactory.getInstance("Ed25519").generatePublic(X509EncodedKeySpec(edPubPrefix + publicKey))
        val s = Signature.getInstance("Ed25519")
        s.initVerify(pub); s.update(message)
        s.verify(signature)
    } catch (e: java.security.GeneralSecurityException) {
        false
    }
}
