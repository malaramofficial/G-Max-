package com.example.meshchat.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.concurrent.thread

/**
 * Photos, videos, documents, voice notes: too big for the BLE mesh, so the BLE message carries only a small
 * encrypted *offer* (file id, key, size, SHA-256, where to connect). The bytes travel over a direct Wi-Fi link
 * (same Wi-Fi network, or a Wi-Fi Direct group the sender hosts), encrypted chunk by chunk with the key from the offer.
 */
object FileCrypto {
    const val CHUNK = 16 * 1024

    fun newKey(): ByteArray = ByteArray(32).also { SecureRandom().nextBytes(it) }
    fun newId(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    private fun cipher(mode: Int, key: ByteArray, counter: Long, aad: ByteArray): Cipher {
        val nonce = ByteBuffer.allocate(12).putInt(0).putLong(counter).array()
        return Cipher.getInstance("AES/GCM/NoPadding").also {
            it.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            it.updateAAD(aad)
        }
    }

    fun encryptChunk(key: ByteArray, counter: Long, fileId: ByteArray, plain: ByteArray): ByteArray =
        cipher(Cipher.ENCRYPT_MODE, key, counter, fileId).doFinal(plain)

    fun decryptChunk(key: ByteArray, counter: Long, fileId: ByteArray, ct: ByteArray): ByteArray =
        cipher(Cipher.DECRYPT_MODE, key, counter, fileId).doFinal(ct)

    fun sha256(file: File): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return md.digest()
    }

    internal fun readChunk(s: InputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) { val n = s.read(buf, off, buf.size - off); if (n < 0) break; off += n }
        return off
    }
}

/** Sender side: serves registered files to anyone who knows the (unguessable) file id and has the key. */
class FileServer {
    private class Entry(val key: ByteArray, val file: File)

    private val files = ConcurrentHashMap<String, Entry>()
    @Volatile private var server: ServerSocket? = null
    @Volatile private var running = false

    val port: Int get() = server?.localPort ?: 0

    fun register(fileId: ByteArray, key: ByteArray, file: File) { files[fileId.toHex()] = Entry(key, file) }
    fun unregister(fileId: ByteArray) { files.remove(fileId.toHex()) }

    @Synchronized
    fun start(preferredPort: Int = 0): Int {
        server?.let { return it.localPort }
        val s = ServerSocket(preferredPort)
        server = s
        running = true
        thread(isDaemon = true, name = "file-server") {
            while (running) {
                val c = try { s.accept() } catch (e: IOException) { break }
                if (!running) { runCatching { c.close() }; break } // a stopped server must never serve a late connection
                thread(isDaemon = true, name = "file-conn") { handle(c) }
            }
        }
        return s.localPort
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { server?.close() }
        server = null
    }

    private fun handle(sock: Socket) {
        sock.use { s ->
            try {
                s.soTimeout = 15_000
                val inp = DataInputStream(BufferedInputStream(s.getInputStream()))
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
                val id = ByteArray(16)
                inp.readFully(id)
                val e = files[id.toHex()]
                if (e == null || !e.file.exists()) { out.writeByte(1); out.flush(); return }
                out.writeByte(0)
                val buf = ByteArray(FileCrypto.CHUNK)
                var counter = 0L
                e.file.inputStream().use { f ->
                    while (true) {
                        val n = FileCrypto.readChunk(f, buf)
                        if (n == 0) break
                        val ct = FileCrypto.encryptChunk(e.key, counter++, id, buf.copyOf(n))
                        out.writeInt(ct.size); out.write(ct)
                        if (n < buf.size) break
                    }
                }
                out.writeInt(0)
                out.flush()
            } catch (e: IOException) {
            } catch (e: GeneralSecurityException) {
            }
        }
    }
}

/** Receiver side. Returns true only if every chunk authenticates and size + SHA-256 match the offer. */
object FileClient {
    fun fetch(
        host: String, port: Int, offer: FileOfferPayload, dest: File,
        connectTimeoutMs: Int = 3000, onProgress: (Long) -> Unit = {},
    ): Boolean {
        val tmp = File(dest.path + ".part")
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), connectTimeoutMs)
                s.soTimeout = 15_000
                val out = DataOutputStream(s.getOutputStream())
                val inp = DataInputStream(BufferedInputStream(s.getInputStream()))
                out.write(offer.fileId); out.flush()
                if (inp.readUnsignedByte() != 0) return false

                val md = MessageDigest.getInstance("SHA-256")
                var counter = 0L
                var total = 0L
                tmp.outputStream().use { fo ->
                    while (true) {
                        val len = inp.readInt()
                        if (len == 0) break
                        if (len < 16 || len > FileCrypto.CHUNK + 16) { tmp.delete(); return false }
                        val ct = ByteArray(len)
                        inp.readFully(ct)
                        val pt = FileCrypto.decryptChunk(offer.key, counter++, offer.fileId, ct)
                        fo.write(pt); md.update(pt)
                        total += pt.size
                        onProgress(total)
                    }
                }
                if (total != offer.size || !md.digest().contentEquals(offer.sha256)) { tmp.delete(); return false }
                dest.delete()
                return tmp.renameTo(dest)
            }
        } catch (e: IOException) {
            tmp.delete(); return false
        } catch (e: GeneralSecurityException) {
            tmp.delete(); return false
        }
    }
}
