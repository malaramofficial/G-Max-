package com.example.meshchat.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.meshchat.ui.MainActivity

object Notifier {
    private const val CH_SERVICE = "mesh_service"
    private const val CH_MSG = "messages"
    private const val CH_CALL = "calls"
    private const val CALL_ID = 4242

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Nearby connection", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, "Calls", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openApp(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun serviceNotification(ctx: Context): Notification =
        NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("MeshChat is looking for nearby phones")
            .setOngoing(true)
            .setContentIntent(openApp(ctx))
            .build()

    /** The ONLY message notification in the app, raised only on the real recipient. */
    fun message(ctx: Context, chatId: String, title: String, text: String) = safeNotify(
        ctx, chatId.hashCode(),
        NotificationCompat.Builder(ctx, CH_MSG)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setContentIntent(openApp(ctx))
            .build(),
    )

    fun cancel(ctx: Context, chatId: String) = NotificationManagerCompat.from(ctx).cancel(chatId.hashCode())

    fun incomingCall(ctx: Context, from: String) = safeNotify(
        ctx, CALL_ID,
        NotificationCompat.Builder(ctx, CH_CALL)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Incoming MeshChat call").setContentText(from)
            .setCategory(NotificationCompat.CATEGORY_CALL).setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true).setTimeoutAfter(45_000)
            .setFullScreenIntent(openApp(ctx), true).setContentIntent(openApp(ctx))
            .build(),
    )

    fun cancelCall(ctx: Context) = NotificationManagerCompat.from(ctx).cancel(CALL_ID)

    private fun safeNotify(ctx: Context, id: Int, n: Notification) {
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { /* permission not granted */ }
    }
}
