#!/usr/bin/env bash
# Compiles the pure-Kotlin core (no Android SDK needed) and runs the self-test.
set -euo pipefail
cd "$(dirname "$0")"
L="${GRADLE_LIB:-/opt/gradle/lib}"
KCP="$L/kotlin-compiler-embeddable-2.0.21.jar:$L/kotlin-stdlib-2.0.21.jar:$L/kotlin-script-runtime-2.0.21.jar:$L/kotlin-reflect-2.0.21.jar:$L/kotlin-daemon-embeddable-2.0.21.jar:$(ls $L/trove4j*.jar $L/annotations-*.jar $L/kotlinx-coroutines-core-jvm-*.jar 2>/dev/null | tr '\n' ':')"
OUT="${TMPDIR:-/tmp}/meshchat-core-out"
rm -rf "$OUT"; mkdir -p "$OUT"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect \
  -cp "$L/kotlin-stdlib-2.0.21.jar" -jvm-target 17 -d "$OUT" \
  ../app/src/main/java/com/example/meshchat/core/*.kt ./*.kt
java -cp "$OUT:$L/kotlin-stdlib-2.0.21.jar" verify.CoreVerifyKt
