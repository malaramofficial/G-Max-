package com.example.meshchat.core

/** Raw 32-byte keys. For Ed25519 the private part is the 32-byte seed. */
class RawKeyPair(val publicKey: ByteArray, val privateKey: ByteArray)

/**
 * The only place that needs Curve25519. The app plugs in a Tink-based implementation
 * (works on every Android version); the self-test plugs in the JDK's built-in one.
 */
interface Curve25519Provider {
    fun newX25519(): RawKeyPair
    /** X25519 Diffie-Hellman. Must throw on an invalid / low-order peer key. */
    fun x25519(privateKey: ByteArray, peerPublic: ByteArray): ByteArray
    fun newEd25519(): RawKeyPair
    fun sign(privateSeed: ByteArray, message: ByteArray): ByteArray
    fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean
}
