package com.example.meshchat.crypto

import com.example.meshchat.core.Curve25519Provider
import com.example.meshchat.core.RawKeyPair
import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Ed25519Verify
import com.google.crypto.tink.subtle.X25519
import java.security.GeneralSecurityException

/** Curve25519 on every Android version (the platform's own X25519/Ed25519 only exists on API 33+). */
class TinkCurve25519Provider : Curve25519Provider {
    override fun newX25519(): RawKeyPair {
        val priv = X25519.generatePrivateKey()
        return RawKeyPair(X25519.publicFromPrivate(priv), priv)
    }

    override fun x25519(privateKey: ByteArray, peerPublic: ByteArray): ByteArray =
        X25519.computeSharedSecret(privateKey, peerPublic)

    override fun newEd25519(): RawKeyPair {
        val kp = Ed25519Sign.KeyPair.newKeyPair()
        return RawKeyPair(kp.publicKey, kp.privateKey)
    }

    override fun sign(privateSeed: ByteArray, message: ByteArray): ByteArray =
        Ed25519Sign(privateSeed).sign(message)

    override fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean = try {
        Ed25519Verify(publicKey).verify(signature, message)
        true
    } catch (e: GeneralSecurityException) {
        false
    } catch (e: IllegalArgumentException) {
        false
    }
}
