package com.example.meshchat.core

import java.security.SecureRandom

/**
 * A group is just a list of members that everyone knows. A group message is sent as one separate sealed
 * packet per member (same message id), so relays still cannot see that it is a group, who is in it, or who it is for.
 * Cost: N-1 packets per message, which is why groups are limited to 8 people.
 */
class Group(val id: ByteArray, val name: String, val members: List<Contact>) {
    val idHex: String get() = id.toHex()
    fun others(me: Identity) = members.filter { !it.edPublic.contentEquals(me.edPublic) }
}

object Groups {
    fun newId(rng: SecureRandom = SecureRandom()): ByteArray = ByteArray(16).also { rng.nextBytes(it) }

    /** Tell every member (except me) about the group: its name and full member list. */
    fun sendInfo(router: MeshRouter, me: Identity, group: Group) {
        val payload = GroupInfoPayload(group.id, group.name, group.members).encode()
        for (m in group.others(me)) router.send(m, Wire.TYPE_GROUP_INFO, payload)
    }

    /** Fan a group text out to every other member. Returns the single message id shared by all copies. */
    fun sendText(router: MeshRouter, me: Identity, group: Group, text: String, replyTo: ByteArray? = null): ByteArray {
        val payload = GroupTextPayload(group.id, TextPayload(text, replyTo)).encode()
        val msgId = ByteArray(16).also { SecureRandom().nextBytes(it) }
        for (m in group.others(me)) router.send(m, Wire.TYPE_GROUP_TEXT, payload, msgId)
        return msgId
    }

    /** Fan any already-encoded payload (e.g. a file offer, a delete) out to every other member. */
    fun sendRaw(router: MeshRouter, me: Identity, group: Group, type: Int, payload: ByteArray, msgId: ByteArray? = null): ByteArray {
        val id = msgId ?: ByteArray(16).also { SecureRandom().nextBytes(it) }
        for (m in group.others(me)) router.send(m, type, payload, id)
        return id
    }
}
