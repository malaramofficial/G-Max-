package com.example.meshchat.call

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.example.meshchat.core.CallAcceptPayload
import com.example.meshchat.core.CallCrypto
import com.example.meshchat.core.CallEndPayload
import com.example.meshchat.core.CallInvitePayload
import com.example.meshchat.core.Contact
import com.example.meshchat.core.Endpoint
import com.example.meshchat.core.FileCrypto
import com.example.meshchat.core.UdpCallChannel
import com.example.meshchat.core.Wire
import com.example.meshchat.net.DirectLinks
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.InetSocketAddress
import java.security.SecureRandom
import kotlin.concurrent.thread

sealed interface CallState {
    data object Idle : CallState
    data class Outgoing(val peer: Contact) : CallState
    data class Incoming(val peer: Contact) : CallState
    data class Active(val peer: Contact, val sinceMs: Long) : CallState
}

/**
 * Voice calls: the *invitation* (call id, key, where to connect) goes through the normal sealed mesh messages;
 * the *audio* then flows directly between the two phones over Wi-Fi (same network or Wi-Fi Direct) as
 * AES-GCM-encrypted 20 ms PCM frames. Audio cannot hop through the BLE mesh (too slow), so both people must be
 * within Wi-Fi range of each other. Calls need a direct link, a limit that is easy to explain to users.
 *
 * NOT yet compiled or run on a device.
 */
class CallManager(
    private val ctx: Context,
    private val links: DirectLinks,
    private val sendSealed: (Contact, Int, ByteArray) -> Unit,
    private val onCallLogged: (peer: Contact, outgoing: Boolean, durationMs: Long, answered: Boolean) -> Unit,
    private val onRinging: (Contact) -> Unit,
) {
    private val _state = MutableStateFlow<CallState>(CallState.Idle)
    val state: StateFlow<CallState> = _state
    private val main = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()

    @Volatile private var callId: ByteArray? = null
    @Volatile private var invite: CallInvitePayload? = null
    @Volatile private var channel: UdpCallChannel? = null
    @Volatile private var audio: AudioEngine? = null
    @Volatile private var weCalled = false
    @Volatile private var epoch = 0
    @Volatile var muted = false
    @Volatile var speaker = false
        set(v) { field = v; audio?.setSpeaker(v) }

    // ---------------- caller ----------------

    @Synchronized
    fun startCall(peer: Contact) {
        if (_state.value != CallState.Idle) return
        val id = ByteArray(16).also { rng.nextBytes(it) }
        val key = FileCrypto.newKey()
        val ch = UdpCallChannel(CallCrypto(key, true))
        callId = id; channel = ch; weCalled = true
        val my = ++epoch
        _state.value = CallState.Outgoing(peer)

        val sendInvite = { ep: Endpoint ->
            sendSealed(peer, Wire.TYPE_CALL_INVITE, CallInvitePayload(id, key, ep).encode())
        }
        val lan = links.lanIpv4()
        if (lan != null) sendInvite(Endpoint(lan, ch.port))
        else links.host { creds ->
            if (creds == null) fail(peer, my) else sendInvite(Endpoint(null, ch.port, creds.first, creds.second))
        }

        // Wait for the callee's first authenticated packet (their "hello"); give up after 60 s.
        thread(isDaemon = true, name = "call-wait") {
            val deadline = System.currentTimeMillis() + 60_000
            while (epoch == my && _state.value is CallState.Outgoing && System.currentTimeMillis() < deadline) {
                if (ch.receive(500) != null) {
                    ch.send(ByteArray(0)) // reply so the callee knows the path works
                    goActive(peer, ch, my)
                    return@thread
                }
            }
            if (epoch == my && _state.value is CallState.Outgoing) hangup()
        }
    }

    fun onAccept(from: Contact, p: CallAcceptPayload) {
        // Nothing to do: the callee's hello over Wi-Fi is the real "connected" signal.
    }

    // ---------------- callee ----------------

    @Synchronized
    fun onInvite(from: Contact, inv: CallInvitePayload) {
        if (_state.value != CallState.Idle) {
            sendSealed(from, Wire.TYPE_CALL_END, CallEndPayload(inv.callId, CallEndPayload.BUSY).encode())
            return
        }
        callId = inv.callId; invite = inv; weCalled = false
        val my = ++epoch
        _state.value = CallState.Incoming(from)
        onRinging(from)
        main.postDelayed({ if (epoch == my && _state.value is CallState.Incoming) decline() }, 45_000)
    }

    @Synchronized
    fun accept() {
        val st = _state.value as? CallState.Incoming ?: return
        val inv = invite ?: return
        val my = epoch
        sendSealed(st.peer, Wire.TYPE_CALL_ACCEPT, CallAcceptPayload(inv.callId).encode())
        thread(isDaemon = true, name = "call-connect") {
            val ch = UdpCallChannel(CallCrypto(inv.key, false))
            channel = ch
            var connected = false
            // 1) same Wi-Fi network?
            inv.endpoint.lanHost()?.let { host ->
                ch.remote = InetSocketAddress(host, inv.endpoint.port)
                connected = hello(ch, 4)
            }
            // 2) otherwise join the caller's Wi-Fi Direct group
            if (!connected && inv.endpoint.ssid.isNotBlank()) {
                val go = joinBlocking(inv.endpoint.ssid, inv.endpoint.passphrase)
                if (go != null) {
                    ch.remote = InetSocketAddress(go, inv.endpoint.port)
                    connected = hello(ch, 12)
                }
            }
            if (epoch != my) { ch.close(); return@thread }
            if (connected) goActive(st.peer, ch, my) else { fail(st.peer, my) }
        }
    }

    @Synchronized
    fun decline() {
        val st = _state.value as? CallState.Incoming ?: return
        callId?.let { sendSealed(st.peer, Wire.TYPE_CALL_END, CallEndPayload(it, CallEndPayload.DECLINED).encode()) }
        onCallLogged(st.peer, false, 0, false)
        cleanup()
    }

    // ---------------- both ----------------

    @Synchronized
    fun hangup() {
        val st = _state.value
        val peer = when (st) { is CallState.Outgoing -> st.peer; is CallState.Active -> st.peer; is CallState.Incoming -> st.peer; else -> return }
        callId?.let { sendSealed(peer, Wire.TYPE_CALL_END, CallEndPayload(it, CallEndPayload.HANGUP).encode()) }
        finish(st, peer)
    }

    @Synchronized
    fun onEnd(from: Contact, p: CallEndPayload) {
        if (callId?.contentEquals(p.callId) != true) return
        val st = _state.value
        if (st is CallState.Idle) return
        finish(st, from)
    }

    private fun finish(st: CallState, peer: Contact) {
        val dur = (st as? CallState.Active)?.let { System.currentTimeMillis() - it.sinceMs } ?: 0L
        onCallLogged(peer, weCalled, dur, st is CallState.Active)
        cleanup()
    }

    private fun fail(peer: Contact, my: Int) {
        if (epoch != my) return
        callId?.let { sendSealed(peer, Wire.TYPE_CALL_END, CallEndPayload(it, CallEndPayload.HANGUP).encode()) }
        onCallLogged(peer, weCalled, 0, false)
        cleanup()
    }

    private fun hello(ch: UdpCallChannel, tries: Int): Boolean {
        repeat(tries) {
            ch.send(ByteArray(0))
            if (ch.receive(700) != null) return true
        }
        return false
    }

    private fun joinBlocking(ssid: String, pass: String): String? {
        val latch = java.util.concurrent.CountDownLatch(1)
        var result: String? = null
        main.post { links.join(ssid, pass) { result = it; latch.countDown() } }
        latch.await(30, java.util.concurrent.TimeUnit.SECONDS)
        return result
    }

    @Synchronized
    private fun goActive(peer: Contact, ch: UdpCallChannel, my: Int) {
        if (epoch != my) return
        _state.value = CallState.Active(peer, System.currentTimeMillis())
        val engine = AudioEngine(ctx, ch) { muted }
        audio = engine
        engine.start(speaker)
        thread(isDaemon = true, name = "call-recv") {
            while (epoch == my && _state.value is CallState.Active) {
                val pcm = ch.receive(300) ?: continue
                if (pcm.isNotEmpty()) engine.play(pcm)
            }
        }
    }

    private fun cleanup() {
        epoch++
        audio?.stop(); audio = null
        runCatching { channel?.close() }; channel = null
        callId = null; invite = null; muted = false
        links.leave()
        _state.value = CallState.Idle
    }
}

/** 16 kHz mono PCM, 20 ms frames. VOICE_COMMUNICATION turns on the phone's echo cancellation. */
@SuppressLint("MissingPermission")
class AudioEngine(private val ctx: Context, private val channel: UdpCallChannel, private val isMuted: () -> Boolean) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var running = false

    fun start(speaker: Boolean) {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        setSpeaker(speaker)
        val inFmt = AudioFormat.CHANNEL_IN_MONO; val enc = AudioFormat.ENCODING_PCM_16BIT
        val recMin = AudioRecord.getMinBufferSize(RATE, inFmt, enc)
        record = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE, inFmt, enc, maxOf(recMin, FRAME * 4))
        val outMin = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, enc)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setEncoding(enc).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(outMin, FRAME * 6))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        running = true
        record?.startRecording(); track?.play()
        thread(isDaemon = true, name = "call-capture") {
            val buf = ByteArray(FRAME)
            while (running) {
                val n = record?.read(buf, 0, FRAME) ?: break
                if (n == FRAME && !isMuted()) runCatching { channel.send(buf.copyOf()) }
            }
        }
    }

    fun play(pcm: ByteArray) { track?.write(pcm, 0, pcm.size) }

    @Suppress("DEPRECATION")
    fun setSpeaker(on: Boolean) { am.isSpeakerphoneOn = on }

    fun stop() {
        running = false
        runCatching { record?.stop(); record?.release() }
        runCatching { track?.stop(); track?.release() }
        record = null; track = null
        am.mode = AudioManager.MODE_NORMAL
    }

    private companion object {
        const val RATE = 16_000
        const val FRAME = 640 // 20 ms of 16-bit mono
    }
}
