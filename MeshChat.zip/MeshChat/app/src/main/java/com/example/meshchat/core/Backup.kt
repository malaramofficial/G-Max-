package com.example.meshchat.core

import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class BackupContent(val identity: Identity, val contacts: List<Contact>)

/**
 * Passphrase-protected backup of the identity (and contact list) so a lost/changed phone does not lose the ID.
 * Chat history is not included. Format: "MCB1" | iterations(4) | salt(16) | nonce(12) | AES-GCM(body).
 */
object Backup {
    private val MAGIC = byteArrayOf('M'.code.toByte(), 'C'.code.toByte(), 'B'.code.toByte(), '1'.code.toByte())
    const val DEFAULT_ITERATIONS = 200_000

    fun export(content: BackupContent, passphrase: String, iterations: Int = DEFAULT_ITERATIONS): ByteArray {
        val w = W()
        val idBytes = content.identity.toBytes()
        w.u16(idBytes.size); w.raw(idBytes)
        w.u16(content.contacts.size)
        for (c in content.contacts) { w.raw(c.edPublic); w.raw(c.xPublic); w.str(c.name, 40) }
        val rng = SecureRandom()
        val salt = ByteArray(16).also { rng.nextBytes(it) }
        val nonce = ByteArray(12).also { rng.nextBytes(it) }
        val ct = cipher(Cipher.ENCRYPT_MODE, passphrase, salt, iterations, nonce).doFinal(w.bytes())
        return ByteBuffer.allocate(4 + 4 + 16 + 12 + ct.size).put(MAGIC).putInt(iterations).put(salt).put(nonce).put(ct).array()
    }

    /** Null for a wrong passphrase or a damaged/foreign file. */
    fun import(data: ByteArray, passphrase: String): BackupContent? = try {
        val b = ByteBuffer.wrap(data)
        val magic = ByteArray(4).also { b.get(it) }
        if (!magic.contentEquals(MAGIC)) null else {
            val iterations = b.int
            if (iterations !in 1_000..5_000_000) null else {
                val salt = ByteArray(16).also { b.get(it) }
                val nonce = ByteArray(12).also { b.get(it) }
                val ct = ByteArray(b.remaining()).also { b.get(it) }
                val pt = cipher(Cipher.DECRYPT_MODE, passphrase, salt, iterations, nonce).doFinal(ct)
                val r = R(pt)
                val identity = Identity.fromBytes(r.raw(r.u16()))
                if (identity == null) null else {
                    val n = r.u16()
                    BackupContent(identity, List(n) { Contact(r.raw(32), r.raw(32), r.str()) })
                }
            }
        }
    } catch (e: GeneralSecurityException) {
        null
    } catch (e: RuntimeException) {
        null
    }

    private fun cipher(mode: Int, passphrase: String, salt: ByteArray, iterations: Int, nonce: ByteArray): Cipher {
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(passphrase.toCharArray(), salt, iterations, 256)).encoded
        return Cipher.getInstance("AES/GCM/NoPadding").also {
            it.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            it.updateAAD(MAGIC)
        }
    }
}
