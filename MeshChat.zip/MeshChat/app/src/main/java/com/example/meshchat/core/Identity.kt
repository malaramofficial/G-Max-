package com.example.meshchat.core

import java.nio.ByteBuffer
import java.util.Base64

/** Display ID derived from the public keys, e.g. "K3F7Q-9XA2M". No server needed; collisions are negligible locally. */
object UserId {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    fun derive(edPublic: ByteArray, xPublic: ByteArray): String {
        val h = Kdf.sha256("meshchat/id/v1".toByteArray(), edPublic, xPublic)
        var bits = 0L
        for (i in 0 until 7) bits = (bits shl 8) or (h[i].toLong() and 0xFF)
        val sb = StringBuilder()
        for (k in 0 until 10) {
            val idx = ((bits shr (56 - 5 * (k + 1))) and 31L).toInt()
            sb.append(ALPHABET[idx])
            if (k == 4) sb.append('-')
        }
        return sb.toString()
    }
}

/** The user's own long-term identity. Private parts must be stored encrypted (see the Android KeyVault). */
class Identity(
    val edPublic: ByteArray,
    val edSeed: ByteArray,
    val xPublic: ByteArray,
    val xPrivate: ByteArray,
    val name: String,
) {
    val userId: String get() = UserId.derive(edPublic, xPublic)

    fun card(p: Curve25519Provider): ContactCard = ContactCard.create(p, this)

    fun toBytes(): ByteArray {
        val n = name.toByteArray(Charsets.UTF_8)
        return ByteBuffer.allocate(128 + 1 + n.size)
            .put(edPublic).put(edSeed).put(xPublic).put(xPrivate)
            .put(n.size.toByte()).put(n).array()
    }

    companion object {
        fun generate(p: Curve25519Provider, name: String): Identity {
            val ed = p.newEd25519()
            val x = p.newX25519()
            return Identity(ed.publicKey, ed.privateKey, x.publicKey, x.privateKey, limitUtf8(name, ContactCard.MAX_NAME_BYTES))
        }

        fun fromBytes(data: ByteArray): Identity? = try {
            val b = ByteBuffer.wrap(data)
            fun take(n: Int) = ByteArray(n).also { b.get(it) }
            val edPub = take(32); val edSeed = take(32); val xPub = take(32); val xPriv = take(32)
            val n = b.get().toInt() and 0xFF
            Identity(edPub, edSeed, xPub, xPriv, String(take(n), Charsets.UTF_8))
        } catch (e: RuntimeException) {
            null
        }
    }
}

internal fun limitUtf8(s: String, maxBytes: Int): String {
    var out = s.trim()
    while (out.toByteArray(Charsets.UTF_8).size > maxBytes) out = out.dropLast(1)
    return out
}

/**
 * What is shown as a QR code / shared to add a friend: both public keys + name, self-signed
 * so a damaged or edited card is rejected. Trust comes from scanning it in person.
 */
class ContactCard(
    val edPublic: ByteArray,
    val xPublic: ByteArray,
    val name: String,
    val signature: ByteArray,
) {
    val userId: String get() = UserId.derive(edPublic, xPublic)

    fun verify(p: Curve25519Provider): Boolean =
        edPublic.size == 32 && xPublic.size == 32 && signature.size == 64 &&
            p.verify(edPublic, signedBytes(edPublic, xPublic, name), signature)

    fun encode(): ByteArray {
        val n = name.toByteArray(Charsets.UTF_8)
        return ByteBuffer.allocate(3 + 32 + 32 + 1 + n.size + 64)
            .put(MAGIC).put(edPublic).put(xPublic).put(n.size.toByte()).put(n).put(signature).array()
    }

    fun toLink(): String = LINK_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(encode())

    fun toContact() = Contact(edPublic, xPublic, name)

    companion object {
        const val MAX_NAME_BYTES = 40
        const val LINK_PREFIX = "meshchat://add/"
        private val MAGIC = byteArrayOf('M'.code.toByte(), 'C'.code.toByte(), '1'.code.toByte())

        private fun signedBytes(ed: ByteArray, x: ByteArray, name: String) =
            "meshchat/card/v1".toByteArray() + ed + x + name.toByteArray(Charsets.UTF_8)

        fun create(p: Curve25519Provider, id: Identity): ContactCard {
            val name = limitUtf8(id.name, MAX_NAME_BYTES)
            return ContactCard(id.edPublic, id.xPublic, name, p.sign(id.edSeed, signedBytes(id.edPublic, id.xPublic, name)))
        }

        fun decode(data: ByteArray): ContactCard? = try {
            val b = ByteBuffer.wrap(data)
            fun take(n: Int) = ByteArray(n).also { b.get(it) }
            if (!take(3).contentEquals(MAGIC)) null else {
                val ed = take(32); val x = take(32)
                val n = b.get().toInt() and 0xFF
                if (n > MAX_NAME_BYTES) null else {
                    val name = String(take(n), Charsets.UTF_8)
                    val sig = take(64)
                    if (b.hasRemaining()) null else ContactCard(ed, x, name, sig)
                }
            }
        } catch (e: RuntimeException) {
            null
        }

        fun fromLink(link: String): ContactCard? = try {
            if (!link.startsWith(LINK_PREFIX)) null
            else decode(Base64.getUrlDecoder().decode(link.removePrefix(LINK_PREFIX)))
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}
